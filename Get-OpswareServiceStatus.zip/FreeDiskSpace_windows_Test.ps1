﻿function Get-Config
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]$ConfigFile # = "config.json"
    ) 
    try
    {
        if (Test-Path -Path $ConfigFile)
        {
            Write-Verbose "Parsing $ConfigFile"
            $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
        }
    }
    catch
    {
        Write-Error "Error Parsing $ConfigFile" 
    }
    Write-Output $config
}
$ConfigFile = "config.json"
$config = Get-Config -ConfigFile $ConfigFile

$username = $config.Username
$password = ConvertTo-SecureString $config.password -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList ($username, $password)
$command_files = "Get-WmiObject win32_logicaldisk"
$FreeDiskSpaceOutput = Invoke-Command -ComputerName WIN-U9B2CKGK4BD -Credential $Cred -ScriptBlock{Invoke-Expression $using:command_files}
$FreeDiskSpace_Result = @()
foreach($disk in $FreeDiskSpaceOutput)
{
    $drive = $disk.DeviceId
    $free = [math]::Round(($disk.'freespace' / 1gb),2)
    $TotalSize = [math]::Round(($disk.'size'/1gb),2)
    $obj = New-Object psObject
    $obj | Add-Member NoteProperty "Drive"  $drive
    $obj | Add-Member NoteProperty "Free Space(GB)"  $free
    $obj | Add-Member NoteProperty "Total Size(GB)"  $TotalSize
    $FreeDiskSpace_Result += $obj
}
$TotalDiskSpace = ($FreeDiskSpace_Result | Measure-Object -Property 'Total Size(GB)' -Sum).Sum
$FreeDiskSpace = ($FreeDiskSpace_Result | Measure-Object -Property 'Free Space(GB)' -Sum).Sum

$percent = [math]::Round((($FreeDiskSpace/$TotalDiskSpace)*100),2)
If($percent -gt 20)
{
    $signal = "G"
}
elseif(($percent -ge 10) -and ($percent -le 20))
{
    $signal = "Y"
}
else
{
    $signal = "R"
}
$FreeDiskSpace_signal = "Free Disk Space, $FreeDiskSpace/$TotalDiskSpace, $percent%, $signal"
$FreeDiskSpace_signal,$FreeDiskSpace_Result
