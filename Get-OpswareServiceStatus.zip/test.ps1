﻿Invoke-Command -ComputerName WIN-U9B2CKGK4BD -Credential Get-Credential -ScriptBlock{Invoke-Expression Get-Service}



Get-WmiObject -Class Win32_Service -ComputerName WIN-U9B2CKGK4BD

Get-CimInstance -ClassName Win32_Service -ComputerName WIN-U9B2CKGK4BD








Get-WmiObject -Query "select * from win32_service where name='WinRM'" -ComputerName WIN-U9B2CKGK4BD |
  Format-List -Property PSComputerName, Name, ExitCode, Name, ProcessID, StartMode, State, Status




Get-WmiObject Win32_Service -Credential administrator -ComputerName WIN-U9B2CKGK4BD