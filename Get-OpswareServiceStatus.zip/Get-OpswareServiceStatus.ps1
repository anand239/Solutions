﻿$username = "auth\sa9550ch"
$password = ConvertTo-SecureString 'amp.menu.once.fort-56347' -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList ($username, $password)
$serverlist = Get-Content -Path "Path of serverlist file"
foreach($server in $serverlist)
{
    $status=Invoke-Command -ComputerName $server -Credential $Cred -ScriptBlock{Get-Service -Name "OpswareAgent"}
    If (($Status.StartType -eq "automatic") -or ($Status.StartType -eq "manual"))
    {
        Write-Host "Opsware Agent is in " $Status.StartType "State for : " $server -BackgroundColor DarkGreen
        if ($Status.Status -eq "stopped")
        {
            Write-Host "Opsware Agent is in" $Status.Status "Status for : " $server -BackgroundColor Red
            Invoke-Command -ComputerName $server -Credential $Cred -ScriptBlock{Start-Service "OpswareAgent"}   #######   Starting the Service  ##########
            Write-Host "Service Started" -BackgroundColor Green -ForegroundColor White
        }
        else
        {
            Write-Host "Opsware Agent is in" $Status.Status "Status for : " $server -BackgroundColor Green
            Write-Host "Continuing"
        }
    }
    else
    {
        Write-Host "Opsware Agent is in " $Status.StartType "State for : " $server -BackgroundColor DarkRed
        Write-Host "Continuing"
    }
}

Write-Host "End of Script" -BackgroundColor Yellow -ForegroundColor Black