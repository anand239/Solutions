﻿cls
$computername = Get-Content "Enter your path containing server names"
foreach($server in $computername)
{
    Invoke-Command -ComputerName $server -ScriptBlock
    {
        $Status = Get-Service -Name "OpswareAgent"

        If (($Status.StartType -eq "automatic") -or ($Status.StartType -eq "manual"))
        {
            Write-Host "Opsware Agent is in " $Status.StartType "State for : " $computername -BackgroundColor DarkGreen
            if ($Status.Status -eq "stopped")
            {
            Write-Host "Opsware Agent is in" $Status.Status "Status for : " $computername -BackgroundColor Red
            #Start-Service $ServiceName

            }
            else
            {
            Write-Host "Opsware Agent is in" $Status.Status "Status for : " $computername -BackgroundColor Green
            Write-Host "Continuing"
            }
        }
        else
        {
            Write-Host "Opsware Agent is in " $Status.StartType "State for : " $computername -BackgroundColor DarkRed
            Write-Host "Continuing"
        }
    }
}



#Invoke-Command -ComputerName $RemoteSystemIP -ScriptBlock $command -credential $Credentials1 -ErrorAction Stop -AsJob