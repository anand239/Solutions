﻿<#
.SYNOPSIS
  Get-DPServiceIDBStatus.ps1

.DESCRIPTION
  To get DP Service status and IDB status.

.INPUTS
  Configfile - config.json
   
.NOTES
  Script:         Get-DPServiceIDBStatus.ps1
  Author:         Chintalapudi Anand Vardhan
  Requirements :  Powershell v3.0
  Creation Date:  12/05/2022
  Modified Date:  12/05/2022 
  Remarks      :  

  .History:
        Version Date            Author                       Description        
        1.0     12/05/2022      Chintalapudi Anand Vardhan   Initial Release
.EXAMPLE
  Script Usage 

  .\Get-DPAReport.ps1 -ConfigFile .\config.json
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [String] $ConfigFile = "config.json"
)

function Get-Config
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]$ConfigFile  = "config.json"
    ) 
    try
    {
        if (Test-Path -Path $ConfigFile)
        {
            Write-Verbose "Parsing $ConfigFile"
            $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
        }
    }
    catch
    {
        Write-Error "Error Parsing $ConfigFile" 
    }
    Write-Output $config
}

$config = Get-Config -ConfigFile $ConfigFile
if($config)
{
    if(!(Test-Path $config.Reportpath))
    {
        Write-Host "Invalid Report path" -BackgroundColor Red
    }
    $Reportpath = $config.Reportpath + "\" + "DPServiceIDBStatus.txt"
    $Result += Get-Date
    $Result += "`n########## Service Status ############`n"
    $Result += Invoke-Expression $config.DPServiceCommand
    $Result += "`n########## IDB Status  ###############`n"
    $Result += Invoke-Expression $config.DPIDBCommand
    $Result | Out-File $Reportpath
}
else
{
    Write-Host "Invalid $ConfigFile" -BackgroundColor Red
}

