﻿Function Get-ListOfSessions
{
    [CmdletBinding()]
    Param(
    $InputObject 
    )
    $ListOfSessions_converted = $InputObject -replace "," -replace "`t","," | Convertfrom-Csv -Header 'Session Type','Specification','Status','Mode','Start Time','Start Time_t','End Time','End Time_t','Queuing', 'Duration','GB Written','Media','Errors','Warnings','Pending DA','Running DA','Failed DA','Completed DA','Object','Files','Success','Session Owner','Session ID'
    $ListOfSessions_Result = $ListOfSessions_converted
    $ListOfSessions_Result
}
$Command = omnirpt -report list_sessions -timeframe 24 24 -tab -no_copylist -no_verificationlist -no_conslist
#$commandoutput = Invoke-Command -ComputerName $Servername -ScriptBlock{Invoke-Expression $using:command}
$ListOfSessions = @(Get-ListOfSessions -InputObject $command)
#$MSSQL_Oracle = $ListOfSessions | where{($_.specification -like "MSSQL*" -or $_.specification -like "oracle*") -and (($_.status -ne "Completed") -and ($_.status -ne "In Progress"))}

$Spec = Read-Host "Please enter the Specification name"

$MSSQL_Oracle = $ListOfSessions | where{($_.specification -eq "$Spec") -and (($_.status -ne "Completed") -and ($_.status -ne "In Progress"))}

"" | Out-File ".\output.txt"
$VSSIssue = @()
if($MSSQL_Oracle)
{
    foreach($session in $MSSQL_Oracle)
    {
        $SessionId = $session.'Session ID'
        $Failed_SessionLog = "omnidb –session $SessionId -report"
        $Garbage = ($Failed_SessionLog | Select-String "Backup Statistics:").LineNumber
        $out = @()
        for($i=0; $i -lt $Garbage-1; $i++)
        {
            $out += $Failed_SessionLog[$i]
        }
        $Critical_Major = @()
        $Replace = (($out) -replace '^$','#')
        $pattern = '#'*1  
        $content =$Replace | Out-String
        $Logs = $content.Split($pattern,[System.StringSplitOptions]::RemoveEmptyEntries)
        foreach($log in $Logs)
        {
            if($Log -like "*Major*" -or $Log -like "*Critical*" -or $log -like "*Minor*")
            {
                $Critical_Major += $Log
            }
        }
        if($Critical_Major)
        {
            if(($Critical_Major -like "*It was not possible to create volume snapshot*") -or ($Critical_Major -like "*Volume Shadow Copy functionality could not be initialized.*"))
            {
                Write-Host "VSS iSSUE" -ForegroundColor Red
                $Critical_Major
                $VSSIssue += "VSS iSSUE"
                $VSSIssue += $Critical_Major
                $Client = ((@($Critical_Major[0] -split "\s" | where{$_ -like "*@*"}))[0] -split "@")[1]
            }
            #elseif($Critical_Major -like "*Not a valid Mount Point*" -or $Critical_Major -like "*Cannot Verify filesystem mount point*")
            #{
            #    $Critical_Major
            #    Write-Host "MountPoint iSSUE" -ForegroundColor Red
            #}
        }
        else
        {
            Write-Host "There are no Critical or Major Errors" -ForegroundColor Cyan
        }
        Write-Host "`n###################################################`n"

    }
    if(!($VSSIssue))
    {
        Write-Host "VSS Issue available" -ForegroundColor Red
    }
}
else
{
    Write-Host "Specification not available in last 24 hours" -ForegroundColor Cyan
}


#########################################################################

$VSSWritersOutput = Get-Content "C:\Users\achintalapud\OneDrive - DXC Production\Documents\UCMS\48692 - Vidya\VssWriters.txt"

$VSSWritersContent = $VSSWritersOutput | Select-String -pattern "Writer name","Writer Id","Writer Instance Id","State","Last error" | where{$_}

$VSSWriters = @()
for($i=0;$i -lt $VSSWritersContent.Count; $i+=5)
{
    $WriterName = ($VSSWritersContent[$i] -split ": ")[1]
    $WriterId   = ($VSSWritersContent[$i+1] -split ": ")[1]
    $WriterInstance = ($VSSWritersContent[$i+2] -split ": ")[1]
    $State = ($VSSWritersContent[$i+3] -split ": ")[1]
    $LastError = ($VSSWritersContent[$i+4] -split ": ")[1]

    $VSSWriters += [pscustomobject] @{
    "WriterName"        = "$WriterName"
    "WriterId"          = $WriterId
    "WriterInstance Id" = $WriterInstance
    "State"             = $State
    "Last Error"        = $LastError
    }
}