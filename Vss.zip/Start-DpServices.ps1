<#
.SYNOPSIS
  Start-DPService.ps1

.DESCRIPTION
  Operations Performed:
    1. Restarting Data Protector Service      
   
.NOTES
  Script:         Start-DPService.ps1
  Author:         Chintalapudi Anand Vardhan
  Requirements :  Powershell v3.0
  Creation Date:  01/07/2022
  Modified Date:  01/07/2022 
  Remarks      :  

  .History:
        Version Date            Author                       Description        
        1.0     01/07/2022      Chintalapudi Anand Vardhan   Initial Release
.EXAMPLE
  Script Usage 

  .\Start-DPService.ps1
#>
[CmdletBinding()]
param(
[Parameter(Mandatory = $true)]
[String] $ConfigFile = "config.json"
)

Function Get-DpService
{
    [CmdletBinding()]
    Param(
    #[parameter(Mandatory = $true)]
    $InputObject 
    )
    #omnisv -status
  
    $Service_Input = $InputObject | Select-String -Pattern ": " | Select-String -Pattern "Status:" -NotMatch
    $Dp_Service_Result = @()
    for($i=0;$i -lt $Service_Input.count;$i++)
    {
        $array = $Service_Input[$i] -split ":"
        $Dp_Service_Result += [PSCUSTOMObject] @{
         "ProcName" =$array[0].trim()
         "Status"= $array[1].trim()
         }
    }
    $Dp_Service_Result_Ignored = $Dp_Service_Result  #| where-object{$_.procname -ne "hpdp-as"}    ###where-object{$_.procname -ne "hpdp-as" -and $_.procname -ne "something"}
    $Total_count = ($Dp_Service_Result_Ignored).Count
    $Active_count = ($Dp_Service_Result_Ignored | Where-Object{$_.'Status' -like "*Active*"}).count
    $percent = [math]::Round(($Active_Count/$Total_count)*100,2)
    #If($percent -eq 0)
    If($percent -lt 100)
    {
        $signal = "R"
    }
    else
    {
        $signal = "G"
    }
    $Dpservice_signal = [PSCUSTOMObject] @{     
    'HC_Name'= "DP Service Status"
    "Value"= "$Active_Count/$Total_count"
    'ValuePercentage' = "$percent%"
    'Status' = "$Signal"
    }
    $Dpservice_signal,$Dp_Service_Result
}

function Get-Config
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]$ConfigFile # = "config.json"
    )
    try
    {
        if (Test-Path -Path $ConfigFile)
        {
            Write-Verbose "Parsing $ConfigFile"
            $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
        }
    }
    catch
    {
        Write-Error "Error Parsing $ConfigFile"
    }
    Write-Output $config
}

function Write-Log
{
    [CmdletBinding()]
    Param(
        [parameter(Mandatory = $true)] 
        [string] $Path,
        [parameter(Mandatory = $true)] 
        $Entry,
        [parameter(Mandatory = $true)]
        [ValidateSet('Error', 'Warning', 'Information', 'Exception')]
        [string] $Type,
        [switch]
        $ShowOnConsole,
        [switch]
        $OverWrite
    )
  
    if ($Type -eq "Error")
    {
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [ERR]  - $Entry"
        if ($ShowOnConsole) { Write-Host "$Entry" -ForegroundColor Red}
    }
    elseif ($Type -eq "Warning")
    { 
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [WARN] - $Entry"
        if ($ShowOnConsole) { Write-Host "$Entry" -ForegroundColor Yellow }
    }
    elseif ($Type -eq "Information")
    { 
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [INFO] - $Entry"
        if ($ShowOnConsole) {  Write-Host "$Entry" -ForegroundColor Green }
    }
    elseif ($Type -eq "Exception")
    { 
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [EXP]  - $Entry"
        if ($ShowOnConsole) {  Write-Host "$Entry" -ForegroundColor Red }
    }
    if($OverWrite)
    {
        $logEntry | Out-File $Path
    }
    else
    {
        $logEntry | Out-File $Path -Append
    }
}

Function Send-Mail
{
    [CmdletBinding()]
    Param(
    $attachments
    )
    $hostname = hostname
#$pass = ConvertTo-SecureString "SMTP Password" -AsPlainText -Force
#$cred = New-Object System.Management.Automation.PSCredential(“SMTP Username”, $pass)
    $sendMailMessageParameters = @{
            To          = $config.mail.To.Split(";")
            from        = $config.mail.From 
            Subject     = "$($config.mail.Subject) on $hostname at $(Get-Date -Format 'dd-MMM-yyyy - HH:mm:ss')"      
            BodyAsHtml  = $true
            SMTPServer  = $config.mail.smtpServer             
            ErrorAction = 'Stop'
            #credential  = $cred
        } 

    if ($config.mail.Cc) 
    { 
        #$cc = $config.mail.Cc.Split(";")
        $sendMailMessageParameters.Add("CC", $config.mail.Cc.Split(";")) 
    }
    if ($attachments.Count -gt 0)
    {
        $sendMailMessageParameters.Add("Attachments", $attachments )
    }
             
    $sendMailMessageParameters.Add("Body", $body)
    try
    {
        Send-MailMessage @sendMailMessageParameters
    }
    catch
    {
        $comment = $_ | Format-List -Force 
        Write-Log -Path $Activitylog -Entry  "Failed to send the mail" -Type Error -ShowOnConsole
        Write-Log -Path $Activitylog -Entry  $comment -Type Exception 
    }
}


$css = @"
<style>
h1, h5, th { font-size: 11px;text-align: center; font-family: Segoe UI; }
table { margin: auto; font-family: Segoe UI; box-shadow: 10px 10px 5px #888; border: thin ridge grey; }
th { background: black; color: #fff; max-width: 200px; padding: 5px 10px; }
td { border: 1px solid black;font-size: 11px;text-align: center; padding: 5px 20px; color: #000; }
tr:nth-child(even) {background: #dae5f4;}
tr:nth-child(odd) {background: #b8d1f3;}
</style>
"@

$configfile="config.json"
$config = Get-Config -ConfigFile $ConfigFile
$Activitylog = "Activity.log"
Write-Log -Path $Activitylog -Entry "Started"                             -Type Information -ShowOnConsole #-OverWrite
Write-Log -Path $Activitylog -Entry "-----------------------------------" -Type Information -ShowOnConsole
#Write-Log -Path $Activitylog -Entry "Host: $($env:COMPUTERNAME)"          -Type Information -ShowOnConsole
#Write-Log -Path $Activitylog -Entry "User: $($env:USERNAME)"              -Type Information -ShowOnConsole
#Write-Log -Path $Activitylog -Entry "-----------------------------------" -Type Information -ShowOnConsole


if($config)
{
    $Dp_Service_Output = Invoke-Expression $config.DPServicecommand
$Dp_Service_Output | Out-File "Activity.log" -Append
"-------------------------------------------------------" | Out-File "Activity.log" -Append

    $Dpservice_signal,$Dp_Service_Result = Get-DpService -InputObject $Dp_Service_Output

    
    if($Dpservice_signal.Status -eq "R")
    {
        omnisv stop
        Start-Sleep -Seconds 10
        omnisv start
        $Dp_Service_Output = omnisv -status
        $Dpservice_signal,$Dp_Service_Result = Get-DpService -InputObject $Dp_Service_Output
    }
    

    if($Dpservice_signal -and $Dp_Service_Result)
    {
        
        if($Dpservice_signal.Status -eq "R")
        {
            $datetime = Get-Date -Format g
            $TZone = [System.TimeZoneInfo]::Local.Id
            $precontent1 = "<b> <font size=+1> Data Protector Service Healthcheck Report  | $datetime ($TZone) </font> </b>"
            $Body = "<br>"
            $Body += $Dpservice_signal | ConvertTo-Html -PreContent "<br> $precontent1 </br><br></br>" -Head $css
            $Body += "<br />"
            $Body += $Dp_Service_Result | ConvertTo-Html -Head $css
            $Body += "<br></br>"
            $body += "<p style=`"color: red; font-size: 12px`">***This is an auto generated mail. Please do not reply.***</p>"
            $body > "htm.html"
            Send-Mail
        }
    }
    else
    {
        Write-Log -Path $Activitylog -Entry "Failed to get data" -Type warning -ShowOnConsole
    }

}
else
{
    Write-Log -Path $Activitylog -Entry "Invalid $ConfigFile" -Type Error -ShowOnConsole
}
Write-Log -Path $Activitylog -Entry "Completed" -Type Information -ShowOnConsole

