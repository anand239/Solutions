﻿Function Get-ListOfSessions
{
    [CmdletBinding()]
    Param(
    $InputObject
    )
    $ListOfSessions_converted = $InputObject -replace "`t","," | Convertfrom-Csv -Header 'Session Type','Specification','Status','Mode','Start Time','Start Time_t','End Time','End Time_t','Queuing', 'Duration','GB Written','Media','Errors','Warnings','Pending DA','Running DA','Failed DA','Completed DA','Object','Files','Success','Session Owner','Session ID'
    $ListOfSessions_Result = $ListOfSessions_converted
    $ListOfSessions_Result
}

$Command = omnirpt -report list_sessions -timeframe 21/09/28 18:00 21/09/29 17:59 -tab -no_copylist -no_verificationlist -no_conslist
$ListOfSessions = @(Get-ListOfSessions -InputObject $Command)
$MSSQL_Oracle = $ListOfSessions | where{($_.specification -like "MSSQL*" -or $_.specification -like "oracle*") -and (($_.status -ne "Completed") -and ($_.status -ne "In Progress"))}



if($MSSQL_Oracle)
{
    foreach($session in $MSSQL_Oracle)
    {
        $SessionId = $session.'Session ID'
        $Failed_SessionLogCommand = "omnidb -session $SessionId -report"
        $Failed_SessionLog = Invoke-Expression $Failed_SessionLogCommand
        $Garbage = ($Failed_SessionLog | Select-String "Backup Statistics:").LineNumber
        $out = @()
        for($i=0; $i -lt $Garbage-1; $i++)
        {
            $out += $Failed_SessionLog[$i]
        }
        $Critical_Major = @()
        $Replace = (($out) -replace '^$','#')
        $pattern = '#'*1  
        $content =$Replace | Out-String
        $Logs = $content.Split($pattern,[System.StringSplitOptions]::RemoveEmptyEntries)
        foreach($log in $Logs)
        {
            if($Log -like "*Major*" -or $Log -like "*Critical*")
            {
                $Critical_Major += $Log
            }
        }
        if($Critical_Major)
        {
            if($Critical_Major -like "*SQLSTATE*")
            {
                $Critical_Major
            }
        }
    }
}