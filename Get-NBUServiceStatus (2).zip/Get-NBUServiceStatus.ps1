﻿<#
.SYNOPSIS
  Get-NBUServiceStatus.ps1
    
.INPUTS
  config.json
  NBUServices.txt

   
.NOTES
  Script:         Update-PriorityFile.ps1
  Author:         Chintalapudi Anand Vardhan
  Requirements :  Powershell v3.0 , Posh-SSH Module, Windows 2008 R2 Or Above
  Creation Date:  11/01/2023
  Modified Date:  11/01/2023 
  Remarks      :  

  .History:
        Version Date            Author                       Description        
        1.0     11/01/2023      Chintalapudi Anand Vardhan   Initial Release
.EXAMPLE
  Script Usage 

  .\Get-NBUServiceStatus.ps1 -ConfigFile .\config.json
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [String] $ConfigFile = "config.json"
)

function Get-Config
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]$ConfigFile # = "config.json"
    ) 
    try
    {
        if (Test-Path -Path $ConfigFile)
        {
            Write-Verbose "Parsing $ConfigFile"
            $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
        }
    }
    catch
    {
        Write-Error "Error Parsing $ConfigFile" 
    }
    Write-Output $config
}

Function Send-Mail
{
    [CmdletBinding()]
    Param(
    $attachments,
    $MailMessage
    )
    $sendMailMessageParameters = @{
            To          = $config.mail.To.Split(";")
            from        = $config.mail.From 
            Subject     = "$($config.mail.Subject) at $(Get-Date -Format 'dd-MMM-yyyy - HH:mm:ss')"      
            BodyAsHtml  = $true
            SMTPServer  = $config.mail.smtpServer             
            ErrorAction = 'Stop'
        } 

    if ($config.mail.Cc) 
    { 
        $sendMailMessageParameters.Add("CC", $config.mail.Cc.Split(";")) 
    }
    if ($attachments.Count -gt 0)
    {
        $sendMailMessageParameters.Add("Attachments", $attachments )
    }
    $sendMailMessageParameters.Add("Body", $MailMessage)
    try
    {
        Send-MailMessage @sendMailMessageParameters
    }
    catch
    {
        $comment = $_ | Format-List -Force 
        Write-Log -Path $Activitylog -Entry  "Failed to send the mail" -Type Error -ShowOnConsole
        Write-Log -Path $Activitylog -Entry  $comment -Type Exception 
    }
}

Function New-PoshSession
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]$IpAddress,
        [Parameter(Mandatory = $true)]
        [PSCredential]$Credential
    )
    try
    {
        $SessionId = New-SSHSession -ComputerName $IpAddress -Credential $Credential -AcceptKey:$true
        write-output $SessionId
    }
    catch
    {
        Write-Output $null
    }

}

function Invoke-NonWindowsCommand
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [int]$SshSessionId,
        [Parameter(Mandatory = $true)]
        [String]$logFile,
        [Parameter(Mandatory = $true)]
        [String]$command,
        [Switch] $UseSSHStream

    )
    try
    {
        '****************************' |  Out-File -FilePath $logFile -Append
        "Running Command : $command" |  Out-File -FilePath $logFile -Append
        '----------------------------' |  Out-File -FilePath $logFile -Append
        $result = ""
        $result = Invoke-SSHCommand -Command $command -SessionId $SshSessionId -EnsureConnection -TimeOut 300 
        $output = $result.output
        if ($result.error)
        {
         "Error Occured"  | Out-File -FilePath $logFile -Append  
         '============================' |  Out-File -FilePath $logFile -Append  
         $result.error | Out-File -FilePath $logFile -Append  
         '============================' |  Out-File -FilePath $logFile -Append  
        }
        $output | Out-File -FilePath $logFile -Append    
        '----------------------------'  | Out-File -FilePath $logFile -Append
        '****************************'  | Out-File -FilePath $logFile -Append
        Write-Output $output
    }
    catch
    {
        Write-Output $null
    }
}

function Write-Log
{
    [CmdletBinding()]
    Param(
        [parameter(Mandatory = $true)] 
        [string] $Path,
        [parameter(Mandatory = $true)] 
        $Entry,
        [parameter(Mandatory = $true)]
        [ValidateSet('Error', 'Warning', 'Information', 'Exception')]
        [string] $Type,
        [switch]
        $ShowOnConsole,
        [switch]
        $OverWrite
    )
  
    if ($Type -eq "Error")
    {
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [ERR]  - $Entry"
        if ($ShowOnConsole) { Write-Host "$Entry" -ForegroundColor Red}
    }
    elseif ($Type -eq "Warning")
    { 
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [WARN] - $Entry"
        if ($ShowOnConsole) { Write-Host "$Entry" -ForegroundColor Yellow }
    }
    elseif ($Type -eq "Information")
    { 
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [INFO] - $Entry"
        if ($ShowOnConsole) {  Write-Host "$Entry" -ForegroundColor Green }
    }
    elseif ($Type -eq "Exception")
    { 
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [EXP]  - $Entry"
        if ($ShowOnConsole) {  Write-Host "$Entry" -ForegroundColor Red }
    }
    if($OverWrite)
    {
        $logEntry | Out-File $Path
    }
    else
    {
        $logEntry | Out-File $Path -Append
    }
}

Function Get-NBUServices
{
    $SSHSession = New-PoshSession -IpAddress $server -Credential $Credential
    $NBUServiceStatus = @()
    if($SSHSession.Connected -eq "True")
    {
        Write-Log -Path $Activitylog -Entry "Connected to $server!" -Type Information -ShowOnConsole
        $NBUServicesData = Invoke-NonWindowsCommand -SshSessionId $SSHSession.Sessionid -command "/usr/openv/netbackup/bin/bpps -x" -logFile $Activitylog
        if($NBUServicesData)
        {
            foreach($Service in $Services)
            {
                if(!($NBUServicesData -like $Service))
                {
                    $NBUServiceStatus += [PsCustomobject]@{
                    ServerName         = $Server
                    ServiceName        = $Service
                    Status             = "Not Running"
                    }
                }
            }
            <#
            if(!($NBUServiceStatus))
            {
                $NBUServiceStatus += [PsCustomobject]@{
                ServerName         = $Server
                ServiceName        = "All Services"
                Status             = "Running"
                }
            }#>
        }
        else
        {
            $NBUServiceStatus += [PsCustomobject]@{
            ServerName         = $Server
            Status             = "Failed to get the Services data"
            }
            Write-Log -Path $Activitylog -Entry "Unable to get Services output from $server" -Type Error -ShowOnConsole
        }
        Remove-SSHSession -SessionId $SSHSession.Sessionid
    }
    else
    {
        $NBUServiceStatus  += [PsCustomobject]@{
        ServerName          = $Server
        Status              = "Failed to Connect to server"
        }
        Write-Log -Path $Activitylog -Entry "failed to connect to $server" -Type Error -ShowOnConsole
    }
    $NBUServiceStatus
}

Function Encrypt-ServerCredentials
{
    [CmdletBinding()]
    Param()
    if(Test-Path $Config.CredentialFile)
    {
        try
        {
        $ClientCredentials = Import-csv $Config.CredentialFile | where{$_}
        #if($ClientCredentials)
        #{
            $UnEncrypted = $ClientCredentials | where{$_.Encrypted -eq "No"}
            if($UnEncrypted)
            {
                $UpdatedCred = @()
                foreach($ClientCredential in $UnEncrypted)
                {
                    $SecurePassword    = $ClientCredential.Password | ConvertTo-SecureString -AsPlainText -Force
                    $EncryptedPassword = $SecurePassword | ConvertFrom-SecureString
                    $ClientCredential.Password = $EncryptedPassword
                    $ClientCredential.Encrypted = "Yes"
                    $UpdatedCred += $ClientCredential
                }
                $UpdatedCred | Export-csv "$($Config.CredentialFile)" -NoTypeInformation
            }
        #}
        #else
        #{
        #    "Unable to get data from $($Config.ClientCredentialFile)"
        #    Exit
        #}
        }
        catch
        {
            $comment = $_ | Format-List -Force 
            Write-Log -Path $Activitylog -Entry "Something went wrong while encrypting credentials." -Type Error -ShowOnConsole
            Write-Log -Path $Activitylog -Entry "Script execution stopped" -Type Error -ShowOnConsole
            Write-Log -Path $Activitylog -Entry  $comment -Type Exception 
            Exit
        }
    }
    else
    {
        Write-Log -Path $Activitylog -Entry "Unable to find $($Config.CredentialFile) file." -Type Error -ShowOnConsole
        Exit
    }
}

Function Get-ServerCredentials
{
    [CmdletBinding()]
    Param(
    $CredentialLines
    )        
    $ServerCred = $CredentialLines | where{($_.Servername -eq $Server) -or ($_.Servername -eq "Any")} | select -First 1
    if(!($ServerCred))
    {
        Write-Log -Path $Activitylog -Entry "Unable to find credentials for $($Server) in $($config.CredentialFile)" -Type Exception -ShowOnConsole 
        Continue
    }
    try
    {
        $ServerUsername      = $ServerCred.Username
        $ServerPassword      = $ServerCred.Password |Convertto-SecureString
        $ServerCredConverted = New-Object System.Management.Automation.PSCredential ($ServerUsername, $ServerPassword)
        $ServerCredConverted
    }
    catch
    {
        Write-Log -Path $Activitylog -Entry "Unable to get credentials for $($Server)" -Type Exception -ShowOnConsole
        Continue
    }
}

$css = @"
<style>
h1, h5, th { font-size: 11px;text-align: center; font-family: Segoe UI; }
table { margin: auto; font-family: Segoe UI; box-shadow: 10px 10px 5px #888; border: thin ridge grey; }
th { background: black; color: #fff; max-width: 200px; padding: 5px 10px; }
td { border: 1px solid black;font-size: 11px;text-align: center; padding: 5px 20px; color: #000; }
tr:nth-child(even) {background: #dae5f4;}
tr:nth-child(odd) {background: #b8d1f3;}
</style>
"@


$config = Get-Config -ConfigFile $ConfigFile
$Activitylog = "Activity.log"
Write-Log -Path $Activitylog -Entry "Started" -Type Information -ShowOnConsole -OverWrite
Write-Log -Path $Activitylog -Entry "-----------------------------------" -Type Information -ShowOnConsole
Write-Log -Path $Activitylog -Entry "Host: $($env:COMPUTERNAME)" -Type Information -ShowOnConsole
Write-Log -Path $Activitylog -Entry "User: $($env:USERNAME)" -Type Information -ShowOnConsole
Write-Log -Path $Activitylog -Entry "-----------------------------------" -Type Information -ShowOnConsole


if($config)
{
    try
    {
        Import-Module ".\Posh-SSH\Posh-SSH.psd1" -ErrorAction Stop
    }
    catch
    {
        Write-Log -Path $Activitylog -Entry "Failed to import Posh-SSH module" -Type warning -ShowOnConsole
        exit
    }
    if(Test-Path -Path $config.CredentialFile)
    {
        $Servers = Import-csv $config.CredentialFile | where{$_}
    }
    else
    {
        Write-Host "Invalid $($config.CredentialFile)!" -ForegroundColor Red
        exit
    }

    if(Test-Path $config.ServicesFile)
    {
        $Services = Get-Content $config.ServicesFile | where{$_}
    }
    else
    {
        Write-Host "Invalid $($config.ServicesFile)!" -ForegroundColor Red
        exit
    }
    Encrypt-ClientCredentials

    if($Servers)
    {
        foreach($Line in $Servers)
        {
            $Server = $Line.Servername
            Write-Log -Path $Activitylog -Entry "Checking For Credential for $server!" -Type Information -ShowOnConsole
            $Credential = Get-ServerCredentials -CredentialLines $Servers
            if($Credential)
            {
                $NBUServicesNotRunning = Get-NBUServices
                if($NBUServicesNotRunning)
                {
                    $body = ""
                    $body += "<p>Hi, <br><br>&nbsp&nbsp&nbsp&nbspPlease find the NBU services status Report.</p>"
                    $body += $NBUServicesNotRunning | ConvertTo-Html -Head $css
                    $body += "<br>Thanks,<br>Automation Team<br>"
                    $body += "<p style=`"color: red; font-size: 12px`">***This is an auto generated mail. Please do not reply.***</p>"
                    Send-Mail -MailMessage $Body
                }
            }
            else
            {
                Send-Mail -MailMessage "Unable to get credential for $Server"
                Write-Log -Path $Activitylog -Entry  "Invalid Credential $server!" -Type Error -ShowOnConsole
            }
        }
    }
    else
    {
        Write-Log -Path $Activitylog -Entry "No data available in $($config.CredentialFile)" -Type Error -ShowOnConsole
    }

}
else
{
    Write-Log -Path $Activitylog -Entry "Invalid $ConfigFile" -Type Error -ShowOnConsole
}
Write-Log -Path $Activitylog -Entry "Completed" -Type Information -ShowOnConsole

