<#
.SYNOPSIS
  Get-DataProtectorHealthCheck.ps1

.DESCRIPTION
  Sends Mail to usernames in csv file if the Password is expiring in lessthan 7 Days.

.INPUTS
  Usernames.csv
   
.NOTES
  Script:         PasswordExpiryNotification.sh
  Author:         Chintalapudi Anand Vardhan
  Creation Date:  25/11/2021
  Modified Date:  25/11/2021 
  Remarks      :  

  .History:
        Version Date            Author                       Description        
        1.0     25/11/2021      Chintalapudi Anand Vardhan   Initial Release
.EXAMPLE
  Script Usage 

  .\PasswordExpiryNotification.sh
#>

#############################################################
1. Provide the Name, Userid, Email in Usernames.csv
2. In PasswordExpiryNotification.sh provide waring Days as per the requirement.
3. Change file permisiions ---> chmod 777 PasswordExpiryNotification.sh
4. Schedule the Script in Crontab according to the need.


##############Scheduling using Crontab################

1.open crontab ---> crontab -e
2. 00 11 * * * /path of script/PasswordExpiryNotification.sh ----> Runs the Script Everyday 11:00
3. exit crontab