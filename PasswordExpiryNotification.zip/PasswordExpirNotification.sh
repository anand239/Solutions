#!/bin/bash

warningdays=7
mailid="a.chintalapudi@dxc.com"
while IFS= read -r line;do
	today=$(date +%s)
	username=`echo $line | cut -d, -f1`
	userid=`echo $line | cut -d, -f2`
	useremail=`echo $line | cut -d, -f3`
	newvar=${#useremail}-1
	newmail=${useremail:0:$newvar}
	echo $newmail | wc -c
	printf $newmail | wc -c
	host=`hostname`
	userexpdate=`chage -l $userid | grep 'Password expires' |cut -d: -f2`
	if [[ "$userexpdate" != *"never"* ]]; then
		passexp=`date -d "$userexpdate" "+%s"`
		#exp=$(($passexp-$today))
		#expday=$(($exp/86400))
		exp=`expr $passexp - $today`
		expday=`expr $exp / 86400`
		if [[ $expday -le $warningdays ]];then
			echo "Hi $username,

Your password for userid : $userid is expiring in $expday day/s on $host.

Automation Team" | mailx -s "Password is Expiring in $expday days" $newmail
fi
	fi
done < <(cat Usernames.csv | sed 1d)


