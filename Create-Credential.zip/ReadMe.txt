1.Provide the Servername, Username, Password and Filepath of the respective servers
  in the Credential.csv.
2.In Configfile provide the file name of Credential.csv(If name used is different).
3.Run the Run.bat, so it creates the credential files in the respective paths of the servers.