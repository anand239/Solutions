﻿<#
.SYNOPSIS
  Get-SystemUtilizationReport.ps1

.DESCRIPTION
  Operations Performed:
    1. System Utilization Report Generation
    
.INPUTS
  Configfile
  config.json
   
.NOTES
  Script:         Get-SystemUtilizationReport.ps1
  Author:         Chintalapudi Anand Vardhan
  Requirements :  Powershell v5.0
  Creation Date:  01/09/2021
  Modified Date:  01/09/2021 
  Remarks      :  

  .History:
        Version Date            Author                       Description        
        1.0     01/09/2021      Chintalapudi Anand Vardhan   Initial Release
.EXAMPLE
  Script Usage 

  .\Get-SystemUtilizationReport.ps1 -ConfigFile .\config.json
#>


[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [String] $ConfigFile = "config.json"
)

function Get-Config
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]$ConfigFile  = "config.json"
    ) 
    try
    {
        if (Test-Path -Path $ConfigFile)
        {
            Write-Verbose "Parsing $ConfigFile"
            $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
        }
    }
    catch
    {
        Write-Error "Error Parsing $ConfigFile" 
    }
    Write-Output $config
}

$config = Get-Config -ConfigFile $ConfigFile
if($config)
{
    $CredentialPath = $config.CredentialFile
    if (!(Test-Path -Path $CredentialPath) )
    {
        $Credential = Get-Credential -Message "Enter Credentials"
        $Credential | Export-Clixml $CredentialPath -Force
    }
    $Credential = Import-Clixml $CredentialPath

    $Date = Read-Host "Enter the date (eg:01/05/2021) : "
    $ReportDate = (Get-Date).ToString("dd_MM_yy")
    $server_file_path = "c:\temp\test_$ReportDate"
    $command = "extract -g -b $date 0:00 -f $server_file_path -xp"    #####  Command to genearte the report

    $serverlist = Get-Content $config.ServerListFile
    if($serverlist)
    {
        $destination = $config.ReportPath
        foreach($server in $serverlist)
        {
            Write-Host "Connecting to $server" -BackgroundColor Green
            try
            {
                $session = New-PSSession -ComputerName $server -Credential $Credential
            }
            catch
            {
                Write-Host "Unable to Connect to $server" -BackgroundColor Red
                continue
            }
            Invoke-Command -Session $session -ScriptBlock{Invoke-Expression $using:command}
            $destination_path=$destination + "\test_$server" + "_" + $ReportDate
            copy -path "$server_file_path" -Destination "$destination_path" -FromSession $session
            Invoke-Command -Session $session -ScriptBlock{Remove-Item -Path $using:server_file_path}
            $Result = Get-Content "$destination_path"
            $inputdata = $Result | select -Skip 2
            $ReportPath = "$destination" +"\"+ "$server" + "_" + "Report" + ".csv"
            $inputdata = $Result | select -Skip 3
            $ReportPath = "$destination" +"\"+ "$server" + "_" + "Report" + ".csv"
            $SelectedResult = $inputdata.replace("|",",")| Convertfrom-Csv -Header 'Date','Time','System uptime(sec)','Sys call rate',
            'System uptime(Hrs)','Allocated CPU',
            'Overall Cpu usage %','System Cpu Utilization',
            'User Cpu Utilization','IDle Cpu Utilization',
            'Memory Physical Read','Memory Physical Write',
            'Physical KB Rate','Physical Read KB Rate','Physical Write KB Rate'

            $SelectedResult | select 'Date','Time','System uptime(sec)',
            'System uptime(Hrs)','Allocated CPU',
            'Overall Cpu usage %','System Cpu Utilization',
            'User Cpu Utilization','IDle Cpu Utilization',
            'Memory Physical Read','Memory Physical Write',
            'Physical KB Rate','Physical Read KB Rate','Physical Write KB Rate' | Export-Csv $ReportPath -NoTypeInformation
            Remove-Item $destination_path
        }
        Get-PSSession | Remove-PSSession
    }
    else
    {
        Write-Host "Server List File cannot be Empty" -BackgroundColor Red
    }
}
else
{
    Write-Host "Invalid $ConfigFile" -BackgroundColor Red
}
