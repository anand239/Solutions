1. Provide the BackupServer names in config.json file seperated by Semicolon(";").
2. Provide the respective mail details.
3. Run the Run.bat file.