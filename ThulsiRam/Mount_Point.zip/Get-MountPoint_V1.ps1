﻿<#
.SYNOPSIS
  Get-MountPoint.ps1

.DESCRIPTION
  Operations Performed:
    1. Server MountPoint Details 
    2. Full Backup Dates
    
.INPUTS
  Configfile
  config.json
   
.NOTES
  Script:         Get-MountPoint.ps1
  Author:         Chintalapudi Anand Vardhan
  Requirements :  Powershell v5.0
  Creation Date:  01/09/2021
  Modified Date:  01/09/2021 
  Remarks      :  

  .History:
        Version Date            Author                       Description        
        1.0     01/09/2021      Chintalapudi Anand Vardhan   Initial Release
.EXAMPLE
  Script Usage 

  .\Get-MountPoint.ps1 -ConfigFile .\config.json
#>


[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [String] $ConfigFile = "config.json"
)

function Get-Config
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]$ConfigFile  = "config.json"
    ) 
    try
    {
        if (Test-Path -Path $ConfigFile)
        {
            Write-Verbose "Parsing $ConfigFile"
            $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
        }
    }
    catch
    {
        Write-Error "Error Parsing $ConfigFile" 
    }
    Write-Output $config
}

$config = Get-Config -ConfigFile $ConfigFile
$logfile = "Activity.log"

if($config)
{
    $Servers = Get-Content $config.ServerListFile | where{$_}
    if($servers)
    {
        Write-Log -Path $logfile -Entry "Started" -Type Information -ShowOnConsole
        Write-Log -Path $logfile -Entry "-----------------------------------" -Type Information -ShowOnConsole

        foreach($Server in $Servers)
        {
            '****************************' |  Out-File -FilePath $logFile -Append
            "Running Command : omnirpt -report host -host $server" |  Out-File -FilePath $logFile -Append
            '----------------------------' |  Out-File -FilePath $logFile -Append

            $Result = omnirpt -report host -host $server ###  Running the Command  ####

            $result | Out-File -FilePath $logFile -Append
            '----------------------------'  | Out-File -FilePath $logFile -Append
            '****************************'  | Out-File -FilePath $logFile -Append

            $Report_Path = $config.Reportpath + "\" + $Server+ "_" + "MountPoint" + ".txt"
            $Result | Out-File $Report_Path
        }
    }
    else
    {
        Write-Log -Path $logfile -Entry "ServerList File cannot be Empty" -Type Error -ShowOnConsole
    }
}
else
{
    Write-Log -Path $logfile -Entry "Invalid $ConfigFile" -Type Error -ShowOnConsole
}
Write-Log -Path $logfile -Entry "Completed" -Type Information -ShowOnConsole
