﻿<#
.SYNOPSIS
  Eject-Tapes.ps1
    
.NOTES
  Script:         Eject-Tapes.ps1
  Author:         Chintalapudi Anand Vardhan
  Requirements :  Powershell v3.0
  Creation Date:  02/03/2023
  Modified Date:  02/03/2023 

  .History:
        Version Date            Author                       Description        
        1.0.0     02/03/2023      Chintalapudi Anand Vardhan   Initial Release
.EXAMPLE
  Script Usage 

  .\Eject-Tapes.ps1 -configfile "config.json"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [String] $ConfigFile = "config.json"
)

function Get-Config
{
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [String]$ConfigFile # = "config.json"
    ) 
    try
    {
        if (Test-Path -Path $ConfigFile)
        {
            Write-Verbose "Parsing $ConfigFile"
            $config = Get-Content -Path $ConfigFile -Raw | ConvertFrom-Json
        }
    }
    catch
    {
        Write-Error "Error Parsing $ConfigFile" 
    }
    Write-Output $config
}

Function Send-Mail
{
    [CmdletBinding()]
    Param(
    $attachments,
    $MailMessage
    )
    $sendMailMessageParameters = @{
            To          = $config.mail.To.Split(";")
            from        = $config.mail.From 
            Subject     = "$($config.mail.Subject) at $(Get-Date -Format 'dd-MMM-yyyy - HH:mm:ss')"      
            BodyAsHtml  = $true
            SMTPServer  = $config.mail.smtpServer             
            ErrorAction = 'Stop'
        } 

    if ($config.mail.Cc) 
    { 
        $sendMailMessageParameters.Add("CC", $config.mail.Cc.Split(";")) 
    }
    if ($attachments.Count -gt 0)
    {
        $sendMailMessageParameters.Add("Attachments", $attachments )
    }
    $sendMailMessageParameters.Add("Body", $MailMessage)
    try
    {
        Send-MailMessage @sendMailMessageParameters
    }
    catch
    {
        $comment = $_ | Format-List -Force 
        Write-Log -Path $Activitylog -Entry  "Failed to send the mail" -Type Error -ShowOnConsole
        Write-Log -Path $Activitylog -Entry  $comment -Type Exception 
    }
}

function Write-Log
{
    [CmdletBinding()]
    Param(
        [parameter(Mandatory = $true)] 
        [string] $Path,
        [parameter(Mandatory = $true)] 
        $Entry,
        [parameter(Mandatory = $true)]
        [ValidateSet('Error', 'Warning', 'Information', 'Exception')]
        [string] $Type,
        [switch]
        $ShowOnConsole,
        [switch]
        $OverWrite
    )
  
    if ($Type -eq "Error")
    {
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [ERR]  - $Entry"
        if ($ShowOnConsole) { Write-Host "$Entry" -ForegroundColor Red}
    }
    elseif ($Type -eq "Warning")
    { 
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [WARN] - $Entry"
        if ($ShowOnConsole) { Write-Host "$Entry" -ForegroundColor Yellow }
    }
    elseif ($Type -eq "Information")
    { 
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [INFO] - $Entry"
        if ($ShowOnConsole) {  Write-Host "$Entry" -ForegroundColor Green }
    }
    elseif ($Type -eq "Exception")
    { 
        $logEntry = "[$(Get-Date -Format "dd-MMM-yyyy HH:mm:ss")] - [EXP]  - $Entry"
        if ($ShowOnConsole) {  Write-Host "$Entry" -ForegroundColor Red }
    }
    if($OverWrite)
    {
        $logEntry | Out-File $Path
    }
    else
    {
        $logEntry | Out-File $Path -Append
    }
}

$css = @"
<style>
h1, h5, th { font-size: 11px;text-align: center; font-family: Segoe UI; }
table { margin: auto; font-family: Segoe UI; box-shadow: 10px 10px 5px #888; border: thin ridge grey; }
th { background: #5F249F; color: #fff; max-width: 200px; padding: 5px 10px; }
td { border: 1px solid black;font-size: 11px;text-align: center; padding: 5px 20px; color: #000; }
tr:nth-child(even) {background: #dae5f4;}
tr:nth-child(odd) {background: #b8d1f3;}
</style>
"@


$config = Get-Config -ConfigFile $ConfigFile
$Activitylog = "Activity.log"
Write-Log -Path $Activitylog -Entry "Started" -Type Information -ShowOnConsole -OverWrite
Write-Log -Path $Activitylog -Entry "-----------------------------------" -Type Information -ShowOnConsole
Write-Log -Path $Activitylog -Entry "Host: $($env:COMPUTERNAME)" -Type Information -ShowOnConsole
Write-Log -Path $Activitylog -Entry "User: $($env:USERNAME)" -Type Information -ShowOnConsole
Write-Log -Path $Activitylog -Entry "-----------------------------------" -Type Information -ShowOnConsole

if($Config)
{
    $servername = hostname
    if(!(Test-Path "InputData.csv"))
    {
        Write-Log -Path $Activitylog -Entry "Unable to get data from InputData.txt" -Type Error -ShowOnConsole
    }
    $Lines = Import-csv "InputData.csv" | where{$_}
    $pattern     = '(?<=\[).+?(?=\])'
    #$ClientIP    = [regex]::Matches($Ping_Raw, $pattern).Value
    $Eject_Result = @()
    foreach($Line in $Lines)
    {
        $Label = $Line.Label
        $RequiredData = [regex]::Matches($Line.Location, $pattern).Value
        $Libraryname   = ($RequiredData -split ":")[0].Trim()
        $Slot          = ($RequiredData -split ":")[1].Trim()
        $command = "omnimm -eject $Libraryname $Slot"
        $Eject_Output = Invoke-Expression $Command
        "Running Command: $Command" | Out-File "Activity.log" -Append
        $Eject_Output | Out-File "Activity.log" -Append
        if($Eject_Output -like "*successfully ejected*")
        {
            $Eject_Result   += [pscustomobject] @{
            "Label"          = $Label
            "Library Name"   = $Libraryname
            "Slot"           = "$SLot"
            "Protection"     = $Line.Protection
            "Eject Status"   = "Success"
            }
        }
        else
        {
            $Eject_Result   += [pscustomobject] @{
            "Label"          = $Label
            "Library Name"   = $Libraryname
            "Slot"           = "$SLot"
            "Protection"     = $Line.Protection
            "Eject Status"   = "Failed"
            }
        }
    }

    $body = ""
    $body += "<p>Hi, <br><br>&nbsp&nbsp&nbsp&nbspPlease find Tape Eject Report.</p>"
    $body += $Eject_Result | ConvertTo-Html -Head $css
    $body += "<br>Thanks,<br>Automation Team<br>"
    $body += "<p style=`"color: red; font-size: 12px`">***This is an auto generated mail. Please do not reply.***</p>"
    Send-Mail -MailMessage $Body
}
else
{
    Write-Log -Path $Activitylog -Entry "Invalid $ConfigFile" -Type Error -ShowOnConsole
}
Write-Log -Path $Activitylog -Entry "Completed" -Type Information -ShowOnConsole



#Final report: 1 cartridges out of 1 successfully entered.