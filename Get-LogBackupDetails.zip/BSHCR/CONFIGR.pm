##############################################################################
#
# FILE   : configr.pm
# Ver    : 1.1
# DATE   : 01/09/2009
# AUTHOR : Yayathi Raju P
#          yayathi.raju@hp.com
#
# DESCRIPTION:
# Configuration Script
#
##########################Change History########################################
# 01/09/2009 Yayathi Raju P.	v1.0 Initial Version
# 01/09/2009 Yayathi Raju P.	v1.1 Updated with new enhancements (Media Report,IDB Status)
################################################################################
BEGIN {
	use Exporter   ();
	our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

	@ISA         = qw(Exporter);
	@EXPORT      = qw(&report_init);
	%EXPORT_TAGS = ( );

	# exported package globals, as well as any optionally exported functions
	@EXPORT_OK   = qw();
}
our @EXPORT_OK;
sub report_init{
($reportpath) = @_;
%reportspecs=();
print "Running Report Init \n" if ($DEBUG);
###### Generating Report File Names & Opening Files ############################
$complspecs = $reportpath."completedspecs.csv";
$longspecs = $reportpath."longrunningspces.csv";
$quedspecs = $reportpath."quedspecs.csv";
$failspecs = $reportpath."failedspecs.csv";
$inpspecs = $reportpath."inprogresspec.csv";
$unknsspecs = $reportpath."unknownspecs.csv";
$servstat = $reportpath."servicestatus.csv";
$libstat = $reportpath."librarystatus.csv";
$disabledspec = $reportpath."disabledspec.csv";
$mediastat = $reportpath."mediastat.csv";
$mediapoolstat = $reportpath."mediapoolstat.csv";
$bkpsummary = $reportpath."bkpsummary.csv";
$idbstatus = $reportpath."idbstatus.csv";
$tmpfile = $reportpath."tmpfile.csv";
$criticalspecs = $reportpath."criticalspecsinp.csv";
$critsp = $reportpath."criticalspecs.csv";

%{$reportspecs{'C Backup Failures'}} = (
widths => '300,120,100,80,80,230,100,100,80,80',
reportheading => 'Failed Backup Report',
tableheading => "Backup Spec,Session ID,Status,Mode,Queuing (in Min),Start Time,Duration (in Min.),Completed DA,Total DA,GB Written",
comparefield => '2',
green => '=~ /(completed$|completed\/Error)/i',
yellow => '=~ /(Queuing|Mount|In Progress)/i',
red => '=~ /(Failed|Aborted|Fail)/i',
history => 'YES',
filepath => "$failspecs"
 );
%{$reportspecs{'D Backups with Queuing Time'}} = (
widths => '300,120,100,80,80,230,100,100,80,80',
reportheading => 'Backups with Queuing Time',
tableheading => "Backup Spec,Session ID,Status,Mode,Queuing (in Min),Start Time,Duration (in Min.),Completed DA,Total DA,GB Written",
comparefield => '4',
green => '<= 5',
yellow => '> 5:< 20',
red => '> 20',
history => 'YES',
filepath => "$quedspecs"
 );
 %{$reportspecs{'B Backup Summary'}} = (
widths => '200,150,150,150,150',
reportheading => 'Backup Summary',
tableheading => "Total Sessions,Completed Sessions,Failed Sessions,In progress Sessions,Unknown Sessions",
comparefield => '2',
green => '== 0',
yellow => '=~ notused',
red => '> 0',
nonbkp => 'YES',
history => 'NO',
filepath => "$bkpsummary"
 );
 %{$reportspecs{'E Long Running Backups'}} = (
widths => '300,120,100,80,80,230,100,100,80,80',
reportheading => 'Long Running Backups',
tableheading => "Backup Spec,Session ID,Status,Mode,Queuing (in Min),Start Time,Duration (in Min.),Completed DA,Total DA,GB Written",
comparefield => '6',
green => '<= 240',
yellow => '> 240:< 500',
red => '> 500',
history => 'YES',
filepath => "$longspecs"
 );
 %{$reportspecs{'F In Progress Backups'}} = (
widths => '300,120,100,80,80,230,100,100,80,80',
reportheading => 'In Progress Backups',
tableheading => "Backup Spec,Session ID,Status,Mode,Queuing (in Min),Start Time,Duration (in Min.),Completed DA,Total DA,GB Written",
comparefield => '2',
green => '=~ /(In Progress)/i',
yellow => '=~ /(Queuing)/i',
red => '=~ /(Mount)/i',
history => 'YES',
filepath => "$inpspecs"
 );
 %{$reportspecs{'A Services Status'}} = (
widths => '200,200',
reportheading => 'Services Status',
tableheading => "Service,Status",
comparefield => '1',
green => '=~ /Active/i',
yellow => '=~ /notused/i',
red => '((!~ /Active/i) && (!~ /\d+-\d+-\d+\s+\d+:\d+:\d+))',
history => 'NO',
nonbkp => 'YES',
filepath => "$servstat"
 );
 %{$reportspecs{'G Library Status'}} = (
widths => '300,400,200,100,60,60,60',
reportheading => 'Library Status',
tableheading => 'Library Name,Library Description,Library Type,IOctl Serial,Total Drives,Enabled Drives,Disbaled Drives',
comparefield => '6',
green => '== 0',
yellow => '=~ /notused/i',
red => '>= 0',
history => 'NO',
nonbkp => 'YES',
filepath => "$libstat"
 );
 %{$reportspecs{'H Disabled Specs'}} = (
widths => '300,200',
reportheading => 'Disabled Specs',
tableheading => "Backup Spec,Status",
comparefield => '1',
green => '=~ /notused/i' ,
yellow => '=~ /Disabled/i',
red => '=~ /notused/i',
history => 'NO',
nonbkp => 'YES',
filepath => "$disabledspec"
 );
 %{$reportspecs{'I Media Status'}} = (
widths => '400,80,80,80',
reportheading => 'Media Status',
tableheading => "Library,Total Media,Scratch Media,Poor Media",
comparefield => '2',
green => '>= 2' ,
yellow => ' == 1',
red => '<= 0',
history => 'NO',
nonbkp => 'YES',
filepath => "$mediastat"
 );
 %{$reportspecs{'J Media Pool Status'}} = (
widths => '250,80,80,80,80,240,100,100',
reportheading => 'Media Pool Status',
tableheading => "Pool Name,Total Media,Free Media,Full Media,Appendable Media,Free Pool Name,Free Media in Free Pool,Total Free Media",
comparefield => '7',
green => '>= 2' ,
yellow => '== 1',
red => '<= 0',
history => 'NO',
nonbkp => 'YES',
filepath => "$mediapoolstat"
 );
  %{$reportspecs{'K IDB Status'}} = (
widths => '300,300,100,120,120,120',
reportheading => 'IDB Status',
tableheading => "Base File Name,Device,No of Extn,Max size with extn (in MB),Utilized Space (in MB),Available Space (in MB)",
comparefield => '5',
green => '> 500',
yellow => '> 250:< 500',
red => '< 250',
history => 'NO',
nonbkp => 'YES',
filepath => "$idbstatus"
 );
 %{$reportspecs{'L Critical Specs'}} = (
widths => '300,120,',
reportheading => 'Critical Backup Specs',
tableheading => "Backup Spec,Status",
comparefield => '1',
green => '=~ /(Success|NoSchedule)/i',
yellow => '=~ /inprogress/i',
red => '=~ /Failure/i',
history => 'NO',
nonbkp => 'YES',
filepath => "$criticalspecs"
 );
 }
 1;
