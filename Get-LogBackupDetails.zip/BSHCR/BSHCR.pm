##############################################################################
#
# FILE   : BSHCR.pm
# Ver    : 1.1
# DATE   : 01/09/2009
# AUTHOR : Yayathi Raju P
#          yayathi.raju@hp.com
#
# DESCRIPTION:
# Module Library for Backup Server Health Check 
#
##########################Change History########################################
# 01/09/2009 Yayathi Raju P.	v1.0 Initial Version
# 01/09/2009 Yayathi Raju P.	v1.1 Updated with new enhancements (Media Report,IDB Status)
################################################################################
BEGIN {
	use Exporter   ();
	our ($VERSION, @ISA, @EXPORT, @EXPORT_OK, %EXPORT_TAGS);

	@ISA         = qw(Exporter);
	@EXPORT      = qw(&staic_web_content &cellservername &dpversion &webcreate1 &web2 &webcreate &criticalspecs &idbcstatus &specsummary &mediainfo &libdetails &webcreate2 &dpstat &printheader &printhtml &sessioninfo &copytemp &printreport &printlinks &disabledspec &getRegistryValue &getpaths);
	%EXPORT_TAGS = ( );

	# exported package globals, as well as any optionally exported functions
	@EXPORT_OK   = qw();
}
our @EXPORT_OK;
use File::Find;
sub staic_web_content {
###############################################################################
# Usage      : &staic_web_content($PageTitle,$FileHandle)
# Purpose    : Prints Header and Static Web Contents
# Returns    : None
# Parameters : $PageTitle,$FileHandle
# Comments   : 
###############################################################################
my ($PageTitle,$fhandle) = @_;
print $fhandle <<OUTT ;
<html>
<head>
<title>$PageTitle</title>
<style type="text/css">
	BODY
	{
		FONT-SIZE: 14pt; FONT-FAMILY: "Times New Roman", Arial, Verdana, Helvetica, Sans-serif;ARIAL;font-weight: bold;
	}
	.ReportTableHeader
	{
		FONT-FAMILY: Arial, Verdana, Helvetica, Sans-serif;
		COLOR: #FF7F50;

	}
	.gridHeader 
	{			
		font-weight: bold;font-size: .8em;	color: #696969;	font-family: Verdana, Arial, Helvetica, sans-serif;
	}
	.hisHeader 
	{			
		font-weight: bold;font-size: .8em;	color: #FF7F50;	font-family: Verdana, Arial, Helvetica, sans-serif;
		BACKGROUND-COLOR: #FFFFFF;
	}
	.hisFirstItem
	{
		BACKGROUND-COLOR:#CC6600;
		border-right: #696969 1px solid;
		padding-right: 4px;
		padding-left: 4px;
		padding-bottom: 4px;
		padding-top: 4px;
		margin: 1px;
		color:#FFFFFF;
		FONT-FAMILY:Candara;
		FONT-SIZE: 9pt;
		font-weight: bold;
		text-align: left;
	}
	
	.mainHeaderArea
	{
		FONT-SIZE: 22pt; FONT-FAMILY: "Times New Roman",ARIAL;font-weight: bold;text-align: center;

	}
	.datetime
	{
		FONT-SIZE: 12pt; FONT-FAMILY: "Times New Roman",ARIAL;text-align: center;

	}
	.gridFirstItem
	{
		BACKGROUND-COLOR:#336699;
		border-right: #696969 1px solid;
		padding-right: 4px;
		padding-left: 4px;
		padding-bottom: 4px;
		padding-top: 4px;
		margin: 1px;
		color:#FFFFFF;
		FONT-FAMILY:Candara;
		FONT-SIZE: 9pt;
		font-weight: bold;
		text-align: left;
	}
	.dataArea {
		FONT-SIZE: 10pt; FONT-FAMILY: ARIAL; BACKGROUND-COLOR: #fafafa;
		text-align: left;

	}
	.dataArea1 {
		FONT-SIZE: 10pt; FONT-FAMILY: ARIAL; BACKGROUND-COLOR: #E3F5F9;
		text-align: left;
	}
	.warning {
		FONT-SIZE: 10pt; FONT-FAMILY: ARIAL; BACKGROUND-COLOR: #FFFF00;
		text-align: center;
	}
	.failure {
		FONT-SIZE: 9pt; FONT-FAMILY: ARIAL; BACKGROUND-COLOR: #FF0000;
		text-align: center;
	}
	.success {
		FONT-SIZE: 9pt; FONT-FAMILY: ARIAL; BACKGROUND-COLOR: #00FF00;
		text-align: center;
	}
	.ColHeaderwidth
	{
		width: 20px;
	}
	table {
		border-collapse: collapse;
	}	
	.hide
	{
		display:none;
	}
	a:link {
		FONT-FAMILY:ARIAL, Candara;
		FONT-SIZE: 9pt;
		text-align: left;
	}
	a:hover {
		font-style: italic;
		FONT-FAMILY:ARIAL, Candara;
		FONT-SIZE: 9pt;
		text-align: left;
	}
	a:visited {
		FONT-FAMILY:ARIAL, Candara;
		FONT-SIZE: 9pt;
		text-align: left;
	}
</style>
</head>
<body bgcolor=#cccccc onload='setupPanes("container1", "tab1");'>
<script>
	var panes = new Array();
	function setupPanes(containerId, defaultTabId)
	{
		panes[containerId] = new Array();
		var maxHeight = 0; var maxWidth = 0;
		var container = document.getElementById(containerId);
		var paneContainer = container.getElementsByTagName("div")[0];
		var paneList = paneContainer.childNodes;
		for (var i=0; i < paneList.length; i++ )
		{
			var pane = paneList[i];
			if (pane.nodeType != 1) continue;
			if (pane.offsetHeight > maxHeight) maxHeight = pane.offsetHeight;
			if (pane.offsetWidth  > maxWidth ) maxWidth  = pane.offsetWidth;
			panes[containerId][pane.id] = pane;
			pane.style.display = "none";
		}
		paneContainer.style.height = maxHeight + "px";
		paneContainer.style.width  = maxWidth + "px";
		document.getElementById(defaultTabId).onclick();
	}
	function showPane(paneId, activeTab)
	{
		for (var con in panes)
		{
				activeTab.blur();
				activeTab.className = "tab-active";
				if (panes[con][paneId] != null)
			{
				var pane = document.getElementById(paneId);
				pane.style.display = "block";
				var container = document.getElementById(con);
				var tabs = container.getElementsByTagName("ul")[0];
				var tabList = tabs.getElementsByTagName("a")
				for (var i=0; i<tabList.length; i++ ) {
					var tab = tabList[i];
					if (tab != activeTab) tab.className = "tab-disabled";
				}
				for (var i in panes[con])
				{
					var pane = panes[con][i];
					if (pane == undefined) continue;
					if (pane.id == paneId) continue;
					pane.style.display = "none"
				}
			}
		}
		return false;
	}
	function show(variable)
	{
		var eleid = document.getElementById(variable);
		
		if(eleid.style.display == 'block')
			eleid.style.display = 'none';
		else
			eleid.style.display = 'block';		
	}
</script>
OUTT
}

sub cellservername {
###############################################################################
# Usage      : $var = cellservername()
# Purpose    : Finds Cell Server Name
# Returns    : Scalar - Cell Server Name.
# Parameters : none
# Comments   : 
###############################################################################
my $server="";
	print "DEBUG=> $omnidbutil -show_cell_name \n" if ($DEBUG);
	if (open CLSRV, "$omnidbutil -show_cell_name |")
	{
		my $row = <CLSRV>;
		chomp($row);
		if ($row =~ m/.*"(.*)"/)
		{
		$row =~ s/.*"(.*)"/\1/g;
		$server = $row;
		}
		$server = `hostname` if (!($server));
		chomp $server;
	}
	return $server;
}

sub dpversion {
###############################################################################
# Usage      : $var = dpversion()
# Purpose    : Finds DP Version
# Returns    : Scalar - DP Version.
# Parameters : none
# Comments   : 
###############################################################################
	my $dpversions="";
	 print "DEBUG=> \$omnidbutil -version \n" if ($DEBUG);
	if (open DPVER, "$omnidbutil -version |")
	{
		my $row = <DPVER>;
		chomp($row);
		$row =~ m/A\.(\d+.\d+)/;
		$dpversions = $1;
	}
	return $dpversions;
}

sub epoch2us {
#################################################################
# Converts date from epoch to US - Start/End time calculation
#################################################################
    my ($epocht) = @_;
    my $usdt="";
	if ((defined($epocht)) && ($epocht ne "") && ($epocht != 0))
	{
		($sec,$min,$hour,$day,$month,$year,$wday,$yday,$isdst)=localtime($epocht);
		$year += 1900;$month++;
		map $_ = &padingvar($_),($month,$day,$hour,$min,$sec);
		$usdt = "$year-$month-$day $hour:$min:$sec";
	}
	return ($usdt)
}
sub durationcalc {
#################################################################
# Duration calculation. from hours minutes to minutes.
#################################################################
        my ($dur) = @_;
        my @tm = split /:/,$dur;
        chomp $tm[0];chomp $tm[1];
        my $dur_min = ($tm[0] * 60) + $tm[1];
        return($dur_min);
}

sub webcreate1 {
###############################################################################
# Usage      : webcreate1
# Purpose    : Creating Web Page
# Returns    : Scalar - DP Version.
# Parameters : $fhandle(file ahndle),$reporttype(Report Name),$paneno (pane no)
# Comments   : 
###############################################################################
	my ($eveex1,$eveex2,$eveex3);
	my ($fhandle,$reporttype,$paneno,$histdays) = @_;
	%temphash = ();my $count=0;
	my $heading = $reportspecs{$reporttype}{'reportheading'};
	my $tableheading = $reportspecs{$reporttype}{'tableheading'};
	my $compfield = $reportspecs{$reporttype}{'comparefield'};
	my $red =  $reportspecs{$reporttype}{'red'};
	my $yellow =  $reportspecs{$reporttype}{'yellow'};
	my $green =  $reportspecs{$reporttype}{'green'};
	my $filepath =  $reportspecs{$reporttype}{'filepath'};
	my $hist =  $reportspecs{$reporttype}{'history'};
	print $fhandle "<p>&nbsp;</p>";
	print $fhandle "<div id=\"pane$paneno\">\n";
	print $fhandle "<p class = gridHeader>$heading</p>\n";
	$twidth = &tablesize($reporttype);
    print $fhandle "<table width=\"$twidth\" border=\"2\">\n";
	@printdata = split /\,/,$tableheading;
	&web2($fhandle,$count,$counter,$reporttype,@printdata);
	$count=1;
	open (DF, "< $filepath") || die "unable to open \$filepath \n";
	print "opened file $filepath \n" if ($DEBUG);
	foreach $line (<DF>)
	{
		chomp $line;
			@columns = split /\,/, $line;
			$temphash{$columns[0]} = $columns[0];
			if (($hist =~ "YES") && (!(exists ($spechistory{$columns[0]}))))
			{
				&datalist_history($columns[0],$histdays);
			}
	}
	@nooflines = (sort(keys(%temphash)));
	if ($#nooflines < 0) {
	print $fhandle "<tr><td colspan =\"10\" class = \"date\" bgcolor=\"#FFFFFF\">No Records</td></tr>";
	$linkstatus{$reporttype}{white}++;
	}
		foreach $spec (sort(keys(%temphash)))
		{
			@sphistory = @{$datahash{$spec}};
			for ($y=0;$y <= $#sphistory;$y++)
			{
				if ($y == 0 ) 
				{
					@printdata= split /\,/,$sphistory[$y];
					$specsafe = $printdata[0];
					$printdata[0] = "<span><a href=\"javascript:show\(\'$reporttype$printdata[0]\'\)\">$printdata[0]</a></span>";
					$eveex1 = &sb($green,'$printdata[$compfield]');
					$eveex2 =  &sb($yellow,'$printdata[$compfield]');
					$eveex3 = &sb($red,'$printdata[$compfield]');
					if (eval $eveex1)
					{
						$linkstatus{$reporttype}{green}++;
						$printdata[$compfield] = "<span style=\"background-color: #00FF00\">$printdata[$compfield]</span>";
					}
					elsif (eval $eveex2)
					{
						$linkstatus{$reporttype}{yellow}++;
						$printdata[$compfield] = "<span style=\"background-color: #FFFF00\">$printdata[$compfield]</span>";
					}
					elsif (eval $eveex3){
						$linkstatus{$reporttype}{red}++;
						$printdata[$compfield] = "<span style=\"background-color: #FF0000\">$printdata[$compfield]</span>";
					}
					
				}
				else
				{
				@tmparry = split /\,/,$sphistory[$y];
				
					$eveex1 = &sb($green,'$_');
					$eveex2 = &sb($yellow,'$_');
					$eveex3 = &sb($red,'$_');
				$tempx = $printdata[0];
				$i = 0;
				@printdata = map 
				{ if ($i == $compfield)
				{
					if (eval $eveex1)
					{
						$linkstatus{$reporttype}{green}++;
						$printdata[$i++]."<br><span style=\"background-color: #00FF00\">$_</span>";
					}
					elsif (eval $eveex2){
						$linkstatus{$reporttype}{yellow}++;
						$printdata[$i++]."<br><span style=\"background-color: #FFFF00\">$_</span>";
					}
					elsif (eval $eveex3){
						$linkstatus{$reporttype}{red}++;
						$printdata[$i++]."<br><span style=\"background-color: #FF0000\">$_</span>";
					}
				}
				else {
				$printdata[$i++]."<br>$_";
				}
				} @tmparry;
				$printdata[0] = $tempx;
				}
			}
			if ($counter == 0) 
			{
				$counter = 1;
			}
			else {
			$counter = 0;
			}
			&web2($fhandle,$count,$counter,$reporttype,@printdata);
			if ($hist =~ "YES") {
				&webcreate($fhandle,$specsafe,$reporttype);
			}
		}
print $fhandle "</table>\n</div>";
close DF;
}

sub web2
{
###############################################################################
# Usage      : &web2($fhandle,$count6,$counter6,$reportt,@columns);
# Purpose    : Creating Web Page - each Record.
# Returns    : None.
# Parameters : $fhandle(file ahndle),$reporttype(Report Name),$paneno (pane no)
# Comments   : 
###############################################################################
my ($fhandle,$count6,$counter6,$reportt,@columns) = @_;
my @width = split /,/,$reportspecs{$reportt}{'widths'};
		my $counter15=1;
        print $fhandle "<tr>\n";
	for ($i=0;$i <= $#columns;$i++)
	{
		if ($columns[0] =~ /HEAD:/i)
		{
			$counter15=0;
			$columns[0] =~ s/HEAD://i;
		}
		if (!($width[$i]))
		{
			if ($i == 0)
			{
				$width[$i] = 250;
			}
			else
			{
				$width[$i] = 120;
			}
		}
		if ($count6 == 0)
		{
			print $fhandle "\t<th class=gridFirstItem align=left width=\"$width[$i]\">\n\t$columns[$i]\n</th>\n";
		}
		elsif ($count6 == 3)
		{
			print $fhandle "\t<th class=hisFirstItem align=left width=\"$width[$i]\">\n\t$columns[$i]\n</th>\n";
		}
		elsif ($counter15 == 0)
		{
			print $fhandle "\t<th class=gridFirstItem align=left width=\"$width[$i]\">\n\t$columns[$i]\n</th>\n";
		}
		else
		{
			if ($counter6 == 0) {
					$class = "dataArea";
			}
			else {
					$class = "dataArea1";
			}
			print $fhandle "\t<td class=$class align=left width=\"$width[$i]\">\n\t$columns[$i]\n</td>\n";
		}
	}
	print $fhandle "</tr>\n";
}

sub tablesize {
	my ($heading) = @_;my $sum=0;
	foreach (split /,/,$reportspecs{$heading}{'widths'}) {
		$sum += $_;
	  }
   return $sum;
}

sub caldmy {
	my ($dt) = @_;my $xmonth=0;my $xday=0;my $xyear=0;
	my ($sec,$min,$hour,$xday,$xmonth,$xyear,$wday,$yday,$isdst)=localtime($dt);
	$xmonth = $xmonth+1;
	$xyear = 1900+$xyear;
	if ($xmonth <= 9) {
			$xmonth = "0".$xmonth;
	}
	if ($xday <= 9) {
			$xday = "0".$xday;
	}
	$wd = $weekdays[$wday];
	$d = "$xmonth/$xday-$wd";
	return($d);
}

sub webcreate {
	my ($fhandle,$spec,$rpt1type) = @_;
	print $fhandle "<tr><td colspan = \"10\">\n";
	#print $fhandle "<p class = gridHeader>HISTORY: $spec</p>\n";
    print $fhandle "<table id=\"$rpt1type$spec\" width=\"$twidth\" border=\"2\" class=\"hide\">\n";
	print $fhandle "<tr><td colspan =\"10\"; class = \"hisHeader\">HISTORY: $spec</td>\n";
	my $count5 = 3; my $counter5 =1;
	@printdata = ("Backup Spec", "Session ID", "Status", "Mode", "Queuing (in Min.)", "Start Time", "Duration (in Min.)", "Completed DA", "Total DA", "GB Written");
	&web2($fhandle,$count5,$counter5,$rpt1type,@printdata);
	my $count5 = 4;
	foreach my $dt (sort(keys(%{$spechistory{$spec}})))
	{
		@sphistory = @{$spechistory{$spec}{$dt}};
		for ($y=0;$y <= $#sphistory;$y++)
		{
			if ($y == 0 ) {
				@printdata= split /\,/,$sphistory[$y];
				if (( $printdata[2] =~ /Completed$/i) || ( $printdata[2] =~ /Completed\/Error/i))
				{
				$printdata[2] = "<span style=\"background-color: #00FF00\">$printdata[2]</span>";
				}
				else {
				$printdata[2] = "<span style=\"background-color: #FF0000\">$printdata[2]</span>";
				}
			}
			else
			{
			@tmparry = split /\,/,$sphistory[$y];
			$tempx = $tmparry[0];
			$i = 0;
			@printdata = map { if ($i == 2){if (( $_ =~ /Completed$/i) || ( $_ =~ /Completed\/Error/i))
				{
						$printdata[$i++]."<br><span style=\"background-color: #00FF00\">$_</span>";
				}
				else {
				$printdata[$i++]."<br><span style=\"background-color: #FF0000\">$_</span>";
				}
				}
						else {
				$printdata[$i++]."<br>$_";
				}
						} @tmparry;
                        $printdata[0] = $tempx;
			}
		}
		if ($counter5 == 0) {
		$counter5 = 1;
	       }
	       else {
		$counter5 = 0;
	       }
		&web2($fhandle,$count5,$counter5,$rpt1type,@printdata);
        }
	print $fhandle "<tr><td colspan =\"10\" class = \"gridHeader\" bgcolor=\"#FFFFFF\">&nbsp\;</td>";
	print $fhandle "</table>\n";
	print $fhandle "</td></tr>\n";
}

sub sb {
#################################################################
# Creating test conditon for Red-Green-Yellow
#################################################################
	my ($val,$val1) = @_;
	chomp $val;my $x;
	my @values = split /:/,$val;
	for ($n=0; $n <= $#values; $n++)
	{
		if ($n == 0) {
		$x = "($val1 $values[$n])";
	}
	else {
		$x = $x." && ($val1 $values[$n])"
	}
	}
	$x = "(".$x.")";
	return ($x);
}

sub criticalspecs {
print "Running Critical Specs Status ..\n" if ($DEBUG);
push (@reportlist,"L Critical Specs");
$critsp = $reportspecs{"L Critical Specs"}{"filepath"};
open (CRITSPECS, "< $criticalspecs") || die "unable to open \$criticalspecs - $criticalspecs \n";
open (CRITSP, "> $critsp") || die "unable to open \$critsp - $critsp \n";
foreach $spec (<CRITSPECS>)
	{
		chomp $spec;
		#print "sp --- $spec \n";
		@sphistory = @{$datahash{$spec}};
		$stat = "";$completed = 0;$inprogress = 0;$failed = 0;
		for ($y=0;$y <= $#sphistory;$y++)
		{
			@printdata= split /\,/,$sphistory[$y];			
				$status = $printdata[2];
				#print "$spec -- $status \n";
			if (($status =~ /Completed$/i) || ($status =~ /Completed\/Error/i))
			{
				$stat = "Success"; $completed = 1;
			}
			elsif (($status =~ /Completed\/Fail/i) || ($status =~ /Failed/i) ||($status =~ /Aborted/i))
			{
				$stat = "Failure" if ((!($stat)) && (!($completed)) && (!($inprogress)));
				$failed = 1;
			}
			elsif (($status =~ /Queuing/i) || ($status =~ /Mount/i) || ($status =~ /In Progress/i))
			{
				$stat = "Inprogress" if (!($completed)); $inprogress = 1;
			}
		}
		$stat = "NoSchedule" if (!($stat));
		print CRITSP "$spec,$stat\n";
	}
	close CRITSP;
}

sub idbcstatus
{
	print "Running IDB Status Report .. \n" if ($DEBUG);
	push (@reportlist,"K IDB Status");
	$idbstatus = $reportspecs{"K IDB Status"}{"filepath"};
    open (IDBSTAT, "> $idbstatus") || die "unable to open \$idbstatus - $idbstatus \n";
 	foreach my $line (`$omnidbutil -extendinfo`)
	{
			chomp $line;
		   if ($line =~ /Base file/i)
		   {
			  $line =~ /Base file\s*\"(.*)\"\s*:/i ;
			  $basefilename=$1;
			  $device="";$spaceleft=0;
		   }
		   elsif ($line =~ /Device/i)
		   {
			  $line =~ /\s*Device\s+\=\s+(.*)\s+$/;
			  $device=$1 if (!($device));
		   }
		   elsif ($line =~ /Number of extensions/i)
		   {
			  $line =~ /\s*Number of extensions\s*\=\s+(.*)/;
			  $nofextn=$1;
			  $nofextn =~ s/\s+//g;
		   }
			elsif ($line =~ /Maximum size with extensions/i)
		   {
			  $line =~ /\s*Maximum size with extensions\s*\=\s*(\d+)\s+.*/;
			  $maxsizewx=$1;
			  $maxsizewx =~ s/\s+//g;
			  if ($maxsizewx > 0)
			  {
				$maxsizewx = sprintf "%.2f",($maxsizewx/(1024));
			  }
		   }
		   elsif ($line =~ /Current size with extensions/i)
		   {
				  $line =~ /\s*Current size with extensions\s*\=\s*(\d+)\s+.*/;
				  $cursizewx=$1;
				  $cursizewx =~ s/\s+//g;
				  if ($cursizewx > 0)
				  {
					$cursizewx = sprintf "%.2f",($cursizewx/(1024));
				  }
				  $device =~ s/\s+$//;
				  $drsizedevice{$device} = $device;
				  #$freembytes = &freedspace($device);
				  $spaceleft = $maxsizewx - $cursizewx;
				  
                     print IDBSTAT "$basefilename,$device,$nofextn,$maxsizewx,$cursizewx,$spaceleft\n";
			}
	}
	print IDBSTAT "HEAD:Device,Max Usage in MB,Max no of files in dir.,Min free space in MB,Used Space (in MB),Available Space (in MB)\n";
    foreach $line (`$omnidbutil -list_dcdir`)
	{
			chomp $line;
			next if ($line !~ /^\s*\d+/);
			$line =~ m/\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(.*)/;
			$alloc_seq=$1;$max_usagemb = $2;$maxfiles_indir = $3;$max_free_mb = $4;$dcdir_dir = $5;
                        chomp $dcdir_dir;
						$dcdir_dir =~ s/\s+$//;
						#$drsizedevice{$dcdir_dir} = $dcdir_dir;
               $bitesindir = &dirSize($dcdir_dir);
			   $spacefree = $max_usagemb - $bitesindir;
			  print IDBSTAT "$dcdir_dir,$max_usagemb,$maxfiles_indir,$max_free_mb,$bitesindir,$spacefree\n";
	}
	print IDBSTAT "HEAD:IDB Directory,,,,,Avail. Space on IDB FS (in MB)\n";
    foreach $line (sort(keys(%drsizedevice)))
	{
			chomp $line;
			 $freembytes = &freedspace($line);
			  print IDBSTAT "$line,,,,,$freembytes\n";
	}
}

sub specsummary {
$c=$f=$i=$u=0;$t = 0;
foreach my $spec (sort(keys(%datahash)))
	{
		@sphistory = @{$datahash{$spec}};
		$stat = 0;$completed = 0;$inprogress = 0;$failed = 0;
		for ($y=0;$y <= $#sphistory;$y++)
		{
			@printdata= split /\,/,$sphistory[$y];			
				$status = $printdata[2];				
			if (($status =~ /Completed$/i) || ($status =~ /Completed\/Error/i))
			{
				$stat = "C"; $completed = 1;
			}
			elsif (($status =~ /Completed\/Fail/i) || ($status =~ /Failed/i) ||($status =~ /Aborted/i))
			{
				$stat = "F" if ((!($stat)) && (!($completed)) && (!($inprogress)));
				$failed = 1;
			}
			elsif (($status =~ /Queuing/i) || ($status =~ /Mount/i) || ($status =~ /In Progress/i))
			{
				$stat = "I" if (!($completed)); $inprogress =1;;
			}
			else 
			{
				$stat = "U" if ((!($stat)) && (!($completed)) && (!($inprogress)) && (!($failed)));;
			}
		}
		$t++;
		if ($stat eq "C") 
		{
			$c++;
		}
		elsif ($stat eq "F") 
		{
			$f++;
		}
		elsif ($stat eq "I")
		{
			$i++;
		}
		elsif ($stat eq "U") 
		{
			$u++;
		}		
	}
print BKPSUMMARY "HEAD: Total Backup Specs,Completed Specs,Failed Specs,Inprogress Specs,Unknown Specs\n";
print BKPSUMMARY "$t,$c,$f,$i,$u\n";
close BKPSUMMARY;
}




sub process_BarDataLists
{
#################################################
# Reading client details from datalist files
################################################

        $DL_path = $File::Find::name;
        $DL_name = $_;
        #print "$DL_path - $DL_name \n";
        if (-d $DL_path)
        {
	print "INFO PROCESS	folder [$DL_path]\n" if ($DEBUG);
	return;
        }
        open (DATALIST, "< $DL_path ") or print "SCHEDULE ERROR unable to open file $DL_path \n";
        binmode DATALIST;
        @datalist = <DATALIST>;
        close DATALIST;
        foreach (@datalist)
        {
                s/\0//g; s/#.*//; s/^\s+|\s+$//;next if /^$/;

                if (m/-disable/){
                print DISABLEDSPEC "$DL_name,DISABLED\n";
                }
        }	
}

sub libdetails {
######################################################
# Finding library details using omnidownload command
######################################################
        print "Running Library Status Data Collection.....\n" if ($DEBUG);
		push (@reportlist,"G Library Status");
		$libstat = $reportspecs{"G Library Status"}{"filepath"};
		open (LIBSTAT, "> $libstat") || die "unable to open \$libstat - $libstat \n"; 
	       print "DEBUG=> $omnidownload -list_libraries -detail" if ($DEBUG);
                $totaldisabledrives = 0; $libstatunknown = 0;  $libstatnotres = 0;
		if (open LIBINF, "$omnidownload -list_libraries -detail 2>&1 |")
		{
		while (<LIBINF>)
		{
               chomp;
               # print "$_ \n";
                if (m/^NAME\s+"(.*)"/) {
                        $lib_name = $1;
                        next;
                }
                if (m/^DESCRIPTION\s+"(.*)"/) {
                        $libinfo{$lib_name}{libdesc} = $1;
						$libinfo{$lib_name}{libdesc} =~ s/,/~/g;
                        next;
                }
                if (m/^HOST\s+(.*)/) {
                        $libinfo{$lib_name}{host} = $1;
                        next;
                }
                if (m/^TYPE\s+(.*)/) {
                        $libinfo{$lib_name}{type} = $1;
                        next;
                }
                if (m/^BARCODEREADER/)
				{
					$libinfo{$lib_name}{BCR}="YES";
					next;
                }
                if (m/^IOCTLSERIAL\s+"(.*)"/) {
                        $libinfo{$lib_name}{IOctlserial} = $1;
                        next;
                }
                if (m/^\t*\s*\"(\d+)\"$/) {
                        $libinfo{$lib_name}{totalslots}++;
                }
			}
			#close LIBINF;
        }
		else {
			print "Error running $omnidownload -list_libraries -detail \n";
		}

		print "DEBUG=> $omnidownload -list_devices -detail" if ($DEBUG);
		if (open DEVINF, "$omnidownload -list_devices -detail 2>&1 |")
		{
			while (<DEVINF>)
			{
	            chomp;
                @test = split /:/;
                if (m/^NAME\s+"(.*)"/) {
                        $drive_name = $1;
                        next;
                }
                if (m/^HOST\s+(.*)/) {
                        $drive_host = $1;
                        next;
                }
                if (m/^TYPE\s+(.*)/) {
                        $drive_type = $1;
                        next;
                }
                if (m/^POOL\s+"(.*)"/) {
                        $drive_pool = $1;
                        next;
                }
                if (m/^LIBRARY\s+"(.*)"/) {
                        $drive_lib = $1;
						$libinfo{$drive_lib}{totaldrives}++;
                        next;
                }
                if (m/^DEVSERIAL\s+(.*)/) {
                        $drive_ser = $1;
                        $libinfo{$drive_lib}{driveinfo}{$drive_name}{drivehost}=$drive_host;
                        $libinfo{$drive_lib}{driveinfo}{$drive_name}{drivetype}=$drive_type;
                        $libinfo{$drive_lib}{driveinfo}{$drive_name}{driveserial}=$drive_ser;
                }
				if (m/disable/i)
				{
					$drive_stat = "Disabled";
					$libinfo{$drive_lib}{disbledrives}++;
					$totaldisabledrives++;
                }
			}
			close DEVINF;
        }
		else {
			print "Error running $omnidownload -list_devices -detail \n" if ($DEBUG);;
		}
	foreach $lib (sort(keys(%libinfo)))
	{
		$libupdrives = $libinfo{$lib}{totaldrives} - $libinfo{$lib}{disbledrives};
		$libinfo{$lib}{disbledrives} = 0 if (!(exists($libinfo{$lib}{disbledrives})));
                if ((exists($libinfo{$lib}{BCR})) && ($libinfo{$lib}{BCR} = "YES")) {
            # foreach $l (`$omnimm -repository_barcode_scan \"$lib\"`)
			# {
                        	# if ($l =~ m/COMPLETED Media Agent/i)
				# {
				    # $libinfo{$lib}{libstatus} = "Responding";
				# }
                                # else
				# {
				    # $libstatnotres++;
				# }
			# }
                }
                if (!(exists($libinfo{$lib}{libstatus}))) {
                        $libinfo{$lib}{libstatus} = "Unknown";
                        $libstatunknown++;
                }
		print LIBSTAT "$lib,$libinfo{$lib}{libdesc},$libinfo{$lib}{type},$libinfo{$lib}{IOctlserial},$libinfo{$lib}{totaldrives},$libupdrives,$libinfo{$lib}{disbledrives}\n";
	}
close LIBSTAT;
}

sub webcreate2 {
	my ($fhandle,$reporttype,$paneno) = @_; 
	%temphash = ();$count=0;
	my $heading = $reportspecs{$reporttype}{'reportheading'};
	my $tableheading = $reportspecs{$reporttype}{'tableheading'};
	my $compfield = $reportspecs{$reporttype}{'comparefield'};
	my $red =  $reportspecs{$reporttype}{'red'};
	my $yellow =  $reportspecs{$reporttype}{'yellow'};
	my $green =  $reportspecs{$reporttype}{'green'};
	my $filepath =  $reportspecs{$reporttype}{'filepath'};
	print $fhandle "<p>&nbsp;</p>";
	print $fhandle "<div id=\"pane$paneno\">\n";
	print $fhandle "<p class = gridHeader>$heading</p>\n";
	my $twidth = &tablesize($reporttype);
    print $fhandle "<table width=\"$twidth\" border=\"2\">\n";
	@printdata = split /\,/,$tableheading;
	&web2($fhandle,$count,$counter,$reporttype,@printdata);
	$count=1;
	open (DF, "< $filepath") || die "unable to open \$filepath \n";
	print "opened file $filepath \n" if ($DEBUG);
	$nl = 0;
	foreach $line (<DF>)
	{
			@printdata =();
			chomp $line;$nl++;
			@printdata = split /\,/, $line;
					if ($printdata[0] !~ /HEAD:/) 
					{
						$eveex1 = $y = &sb($green,'$printdata[$compfield]');
						$eveex2 = $y = &sb($yellow,'$printdata[$compfield]');
						$eveex3 = $y = &sb($red,'$printdata[$compfield]');
						if (eval $eveex1)
						{
							$printdata[$compfield] = "<span style=\"background-color: #00FF00\">$printdata[$compfield]</span>";
							$linkstatus{$reporttype}{green}++;
						}
						elsif (eval $eveex2)
						{
							$printdata[$compfield] = "<span style=\"background-color: #FFFF00\">$printdata[$compfield]</span>";
							$linkstatus{$reporttype}{yellow}++;
						}
						elsif (eval $eveex3){
							$printdata[$compfield] = "<span style=\"background-color: #FF0000\">$printdata[$compfield]</span>";
							$linkstatus{$reporttype}{red}++;
						}
					}
			if ($counter == 0) 
			{
				$counter = 1;
			}
			else {
			$counter = 0;
			}
			$ln = $printdata[0];
			if ( $reporttype eq "I Media Status" )
			{
			$printdata[0] = "<span><a href=\"javascript:show\(\'$printdata[0]\'\)\">$printdata[0]</a></span>";
			}			
			&web2($fhandle,$count,$counter,$reporttype,@printdata);
			#print "rept -- $reporttype \n";
			if ( $reporttype eq "I Media Status" )
			{
			&libhiswebcreate($fhandle,$ln,$reporttype);
			}
	}
	if ($nl == 0) {
	print $fhandle "<tr><td colspan =\"10\" class = \"date\" bgcolor=\"#FFFFFF\">No Records</td></tr>";
	$linkstatus{$reporttype}{white}++;
	}
print $fhandle "</table>\n</div>";
close DF;
}

sub dpstat {
######################################################
# Finding DP Status
######################################################
     print "Running DP Staus .....\n" if ($DEBUG); 
	 push (@reportlist,"A Services Status");
	 $servstat = $reportspecs{"A Services Status"}{"filepath"};
	 open (SRVSTAT, "> $servstat") || die "unable to open \$servstat - $servstat \n"; 
	if (open DPSTATUS, "$omnisv -status |")
	{
		while (<DPSTATUS>)
		{
			chomp;
			next if /^=/;
			next if /ProcName/i;
			if (/^status:/i) {
				if ( $line =~ /not running/i )
				{
					print "DP services are not running\n";
					$dstat = "NOT RUNNING";
				}
				else 
				{
					$dpstat = "RUNNING";
				}
				next;
			}
			next if /traps/i;
			($a,$b) = split/:/;
			$a =~ s/\s+//g;
			$b =~ s/\s+//g;
			print SRVSTAT "$a,$b\n";
		}
	}
	else {
		print "Error -  \$omnisv not found - Path Error";
	}
	open (INP, "< $omnisvlogpath") || die "Unable to Open file $omnisvlogpath \n";
	@arrays = <INP>;
	@startt = grep /START$/,@arrays;
	chomp $startt[$#startt];
	$startt[$#startt] =~ /(\d+-\d+-\d+ \d+:\d+:\d+)\s+-\s+START/;
	$svstarttime = $1;
	@stopt = grep /STOP$/,@arrays;
	chomp $stopt[$#stopt];
	$stopt[$#stopt] =~ /(\d+-\d+-\d+ \d+:\d+:\d+)\s+-\s+STOP/;
	$svstoptime = $1;
	print SRVSTAT "HEAD:Services Last Stopped,Services Last Started\n";
	print SRVSTAT "$svstoptime,$svstarttime\n";
	#print SRVSTAT "HEAD:Services Last Started,\n";
	#print SRVSTAT "$svstarttime,\n";
	close INP;
close SRVSTAT;
return ($dpstat);
}

sub padingvar {
        my ($b_pad) = @_;
        if ($b_pad <= 9) {
                $b_pad = "0".$b_pad;
        }
return $b_pad;
}


sub datalist_history {
my ($historyspec,$historydays) = @_;
my $starthours = $historydays * 24;
my $durhours = ($historydays - 1) * 24;
	if (open BKPREPLIST, "$omnirpt -report list_sessions -datalist \"$historyspec\" -timeframe $starthours $durhours -tab |")
	{
		foreach (<BKPREPLIST>)
		{
			chomp;
			next if m/^#/;
			if ($dpversion >= 6.1) {
				($bkpspec,$status,$mode,$starttime,$endtime,$queing,$duration,$gbwritten,$completedda,$totalda,$sesfiles,$sessionid) = (split /\t+/)[1,2,3,5,7,8,9,10,17,18,19,22];
			}
			else {
				($bkpspec,$status,$mode,$starttime,$endtime,$queing,$duration,$gbwritten,$completedda,$totalda,$sesfiles,$sessionid) = (split /\t+/)[0,1,2,4,6,7,8,9,16,17,18,21];
			}
			
			$dt = &caldmy($starttime);
			$starttime = &epoch2us($starttime);
			$endtime = &epoch2us($endtime);
			$duration = &durationcalc($duration);
			$queing = &durationcalc($queing);
			$val = "$dt,$sessionid,$status,$mode,$queing,$starttime,$duration,$completedda,$totalda,$gbwritten";
			push(@{$spechistory{$bkpspec}{$dt}},$val)
		}
	}
	else {
	print "unable to run - omnirpt -report list_sessions -datalist -timeframe $starthours $durhours -tab \n"; 
	}
}

sub printheader {
###############################################################################
# Usage      : &printheader($heading,$fhandle,$cellserver)
# Purpose    : Print Report Heading
# Returns    : None
# Parameters : $PageTitle,$FileHandle
# Comments   : 
###############################################################################
	my ($heading,$fhandle,$cellserver,$customer,$version) = @_;
	my ($sec,$min,$hour,$pday,$pmonth,$pyear,$wday,$yday,$isdst)=localtime(time());
	$pmonth = $pmonth + 1;
	$pyear = 1900 + $pyear;
	if ($pmonth <= 9) {
		$pmonth = "0".$pmonth;
	}
	if ($pday <= 9 ) {
		$pday = "0".$pday;
        }
	print $fhandle "<p class = mainHeaderArea>$heading<br><font size=\"2\">     Ver.: $version</font></p>";
    print $fhandle "<p class = datetime>Customer: $customer<br>Cell Server: $cellserver<br>Date: $pday/$pmonth/$pyear $hour:$min:$sec</p>\n";
}

sub printhtml {
my ($client_fhandle) = @_;
    print "Running print HTML .....\n" if ($DEBUG); 
	&staic_web_content($PageTitle,$client_fhandle);
	$heading = "Backup Server Health Check Report";
    &printheader($heading,$client_fhandle,$cellserver,$customer,$version);
}

sub sessioninfo {
($longrunning_hours) =@_;
print "Running Backup Activity Data collection.....\n" if ($DEBUG);
#################################################################
# Collects Session Information using omnidb and omnirpt commands
# Also calls routine for collecting each object information
# Data stored to %sesssionstatus
#################################################################
#Duration calc
#################################################################
	($sec,$min,$hour,$day,$month,$year,$wday,$yday,$isdst)=localtime(time());
	$daystartsec = 86400;
	$duration = 86400;
	$starthours = int($daystartsec/3600)+1;
	$durhours = int($duration/3600)+1;
##########################################################################
	push (@reportlist,"B Backup Summary");
	push (@reportlist,"C Backup Failures");
	push (@reportlist,"D Backups with Queuing Time");
	push (@reportlist,"E Long Running Backups");
	push (@reportlist,"F In Progress Backups");
	$longspecs = $reportspecs{"E Long Running Backups"}{"filepath"};
	$quedspecs = $reportspecs{"D Backups with Queuing Time"}{"filepath"};
	$failspecs = $reportspecs{"C Backup Failures"}{"filepath"};
	$inpspecs = $reportspecs{"F In Progress Backups"}{"filepath"};
	$bkpsummary = $reportspecs{'B Backup Summary'}{"filepath"};
	open (LONGRS, "> $longspecs") || die "unable to open \$longspecs - $longspecs \n";    
	open (QUEDS, "> $quedspecs") || die "unable to open \$quedspecs - $quedspecs \n";
	open (COMPLS, "> $complspecs") || die "unable to open \$complspecs - $complspecs \n";
	open (FAILS, "> $failspecs") || die "unable to open \$failspecs - $failspecs\n";
	open (INPS, "> $inpspecs") || die "unable to open \$inpspecs - $inpspecs\n";
	open (UNKNS, "> $unknsspecs") || die "unable to open \$unknsspecs - $unknsspecs \n";
	open (BKPSUMMARY, "> $bkpsummary") || die "unable to open \$bkpsummary - $bkpsummary \n";
	my $completed_sessions=0;my $failed_sessions=0;my $inprog_sessions=0;my $unknown_sessions=0;my $linklistonce=0;
    print "DEBUG=> \$daystartsec - $daystartsec,\$duration - $duration,\$starthours - $starthours,\$durhours - $durhours \n"  if ($DEBUG);
    print "DEBUG=> $omnidb -session -type backup -wo  $daystartsec $duration \n" if ($DEBUG);
	if (open BKPSESLIST, "$omnidb -session -type backup -wo $daystartsec $duration |")
	{
		while (<BKPSESLIST>)
		{
			chomp;
			next if m/^[^\d+]/;
			($sessionid) = (split /\s+/)[0];
			$backupsession{$sessionid} = $sessionid;
		}
	close BKPSESLIST;
	}
	else {
		print "Error $omnidb -session -type backup -wo $daystartsec $duration \n";
	}
	if (open BKPREPLIST, "$omnirpt -report list_sessions -timeframe $starthours $durhours -tab |")
	{
		foreach (<BKPREPLIST>)
		{
			chomp;
			next if m/^#/;
			if ($dpversion >= 6.1) {
				($bkpspec,$status,$mode,$starttime,$endtime,$queing,$duration,$gbwritten,$completedda,$totalda,$sesfiles,$sessionid) = (split /\t+/)[1,2,3,5,7,8,9,10,17,18,19,22];
			}
			else {
				($bkpspec,$status,$mode,$starttime,$endtime,$queing,$duration,$gbwritten,$completedda,$totalda,$sesfiles,$sessionid) = (split /\t+/)[0,1,2,4,6,7,8,9,16,17,18,21];
			}
			if (exists $backupsession{$sessionid})
			{
				$total_sessions++;
				$starttime = &epoch2us($starttime);
				$endtime = &epoch2us($endtime);
				$duration = &durationcalc($duration);
				$queing = &durationcalc($queing);
				$r = "$bkpspec,$sessionid,$status,$mode,$queing,$starttime,$duration,$completedda,$totalda,$gbwritten";
				#print "val - $r \n";
                push(@{$datahash{$bkpspec}},$r);
				if ($duration >= ($longrunning_hours * 60))
				{
					print LONGRS "$bkpspec,$sessionid,$status,$mode,$queing,$starttime,$duration,$completedda,$totalda,$gbwritten\n";
				}
				if ($queing >= 2)
				{
					print QUEDS "$bkpspec,$sessionid,$status,$mode,$queing,$starttime,$duration,$completedda,$totalda,$gbwritten\n";
				}				
				if (($status =~ /Completed$/i) || ($status =~ /Completed\/Error/i))
				{
					$completed_sessions++;
					print COMPLS "$bkpspec,$sessionid,$status,$mode,$queing,$starttime,$duration,$completedda,$totalda,$gbwritten\n";
					if ((exists($plus2fail{$bkpspec})))
					{
						delete($plus2fail{$bkpspec});
					}
				}
				elsif (($status =~ /Completed\/Fail/i) || ($status =~ /Failed/i) ||($status =~ /Aborted/i))
				{
					$failed_sessions++;
					print FAILS "$bkpspec,$sessionid,$status,$mode,$queing,$starttime,$duration,$completedda,$totalda,$gbwritten\n";
					if (!exists($dontoday{$bkpspec})) 
					{
                        $plus2fail{$bkpspec}++;
                        $donetoday{$bkpspec}="yes";
                    }
				}
				elsif (($status =~ /Queuing/i) || ($status =~ /Mount/i) || ($status =~ /In Progress/i))
				{
					$inprog_sessions++;
					print INPS "$bkpspec,$sessionid,$status,$mode,$queing,$starttime,$duration,$completedda,$totalda,$gbwritten\n";
				}				
				else
				{
					$unknown_sessions++;
					print UNKNS "$bkpspec,$sessionid,$status,$mode,$queing,$starttime,$duration,$completedda,$totalda,$gbwritten\n";
				}
			}
		}
		close BKPREPLIST;
	}
	else {
	print "Error running $omnirpt -report list_sessions -timeframe $starthours $durhours -tab \n";
	}
close LONGRS;
close QUEDS;
close COMPLS;
close FAILS;
close INPS;
close UNKNS;
print BKPSUMMARY "$total_sessions,$completed_sessions,$failed_sessions,$inprog_sessions,$unknown_sessions\n";
&specsummary; 
}

sub copytemp {
	my ($fhandle) = @_;
	open (TMPF, "< $tmpfile") || die "unable to open \$tmpfile - $tmpfile \n";
	while (<TMPF>)
	{
	print $fhandle "$_";
	}
	close TMPF;
}

sub printreport {
	my ($histdays,$fhandle,@link1)=@_;
	open (TMPF, "> $tmpfile") || die "unable to open \$tmpfile - $tmpfile \n"; 
	$TMPH = "TMPF";
	print $TMPH "<div class=\"tab-panes\">\n";
	for ($r=0;$r <= $#link1;$r++){
		$nonb = $reportspecs{$link1[$r]}{'nonbkp'};
		if ($nonb =~ "YES") 
		{
		&webcreate2($TMPH,$link1[$r],$r);
		}
		else 
		{
		&webcreate1($TMPH,$link1[$r],$r,$histdays);
		}
	}
	close TMPF;
}

sub printlinks {
my ($fhandle,@link)=@_;
print $fhandle <<OUT2;
<div class="tab-container" id="container1">
<ul class="tabs">
OUT2

	$noofcells=0;
	print $fhandle "<table width=\"100%\" border=\"2\">\n<tr>\n";
	for ($i=0;$i <= $#link;$i++){
		chomp $link[$i];
		$heading = $reportspecs{$link[$i]}{'reportheading'};
		$lgreen = $linkstatus{$link[$i]}{'green'};
		$lyellow = $linkstatus{$link[$i]}{'yellow'};
		$lred = $linkstatus{$link[$i]}{'red'};
		$lwhite = $linkstatus{$link[$i]}{'white'};
		print "--$link[$i]-$fhandle-$lgreen-$lyellow-$lred-$lwhite \n" if ($DEBUG);
		if ( $i == 0 ) {
		if ($lwhite > 0) {
		 print $fhandle "<td><li><a href=\"#\" onClick=\"return showPane('pane0', this)\" id=\"tab1\"><b><font color=\"#FFFFFF\">$heading</font></b></a></li></td>\n";
		 $noofcells = $noofcells + 1;
		 }
		elsif ($lred > 0) {
		 print $fhandle "<td><li><a href=\"#\" onClick=\"return showPane('pane0', this)\" id=\"tab1\"><b><font color=\"#FF0000\">$heading</font></b></a></li></td>\n";
		 $noofcells = $noofcells + 1;
		 }
		 elsif ($lyellow > 0)
		 {
		 print $fhandle "<td><li><a href=\"#\" onClick=\"return showPane('pane0', this)\" id=\"tab1\"><b><font color=\"#FFFF00\">$heading</font></b></a></li></td>\n";
		 $noofcells = $noofcells + 1;
		 }
		 else 
		 {			 
		 print $fhandle "<td><li><a href=\"#\" onClick=\"return showPane('pane0', this)\" id=\"tab1\"><b><font color=\"#009900\">$heading</font></b></a></li></td>\n";
		 $noofcells = $noofcells + 1;
		 }
	        } else {
			if ($lwhite > 0) {
			 print $fhandle "<td><li><a href=\"#\" onClick=\"return showPane('pane$i', this)\"><b><font color=\"#FFFFFF\">$heading</font></b></a></li></td>\n";
			 $noofcells = $noofcells + 1;
			 }
			elsif ($lred > 0) {
		 print $fhandle "<td><li><a href=\"#\" onClick=\"return showPane('pane$i', this)\"><b><font color=\"#FF0000\">$heading</font></b></a></li></td>\n";
		 $noofcells = $noofcells + 1;
		 }
		 elsif ($lyellow > 0)
		 {
		 print $fhandle "<td><li><a href=\"#\" onClick=\"return showPane('pane$i', this)\"><b><font color=\"#FFFF00\">$heading</font></b></a></li></td>\n";
		 $noofcells = $noofcells + 1;
		 }
		 else 
		 {			 
		 print $fhandle "<td><li><a href=\"#\" onClick=\"return showPane('pane$i', this)\"><b><font color=\"#009900\">$heading</font></b></a></li></td>\n";
		 $noofcells = $noofcells + 1;
		 }
		}
		if  ($noofcells >= 4) {
		      print $fhandle "</tr>\n<tr>\n";
		      $noofcells=0;
		}
	}
	print $fhandle "</tr>\n";
	print $fhandle "</table>\n";
	print $fhandle "</ul>\n";
}
sub disabledspec {
	print "Running Disabled Spec Data collection\n" if ($DEBUG);
	push (@reportlist,"H Disabled Specs");
	$disabledspec = $reportspecs{"H Disabled Specs"}{"filepath"};
	open (DISABLEDSPEC, "> $disabledspec") || die "unable to open \$diabledspec - $diabledspec \n"; 
	find(\&process_BarDataLists, ("$config_path"));
	close DISABLEDSPEC;	
}

sub getRegistryValue {
############################################################################################
# getRegistryValue {{{
# Purpose: Get a key value from registry
# Argument: key, subkey
# Return: subkey value
################################################################
	($kk,$kn) = @_;
	# Get the system type - whether the system is 32 or 64 bit
	$sysinfo = `systeminfo \| findstr /i \"system\" \| findstr /i \"type:\"`;
	if ($?) {
		$sysinfo = `set PROCESSOR_ARCHITECTURE` or print ("detection of architecture failed with: $! and return code $?");
	}
	if ( $sysinfo =~ /x86/i ) {
		$sys_type = '32';
	}

	if ( $sysinfo =~ /x64/i ) {
		$sys_type = '64';
	}

	if ( $sys_type eq '32' ) {
		@rg = `reg.exe query $kk /v $kn`;
		$rg = join(' ', @rg);
	}

	if ( $sys_type eq '64' ) {
		@rg = `reg_x64.exe query $kk /v $kn`;
		$rg = join(' ', @rg);
	}

	$rg =~ s/\s\s+/\t/g;
	$rg =~ s/ /#@#/g;
	$rg =~ s/\s/\t/g;
	$rg =~ s/#@#/ /g;
	@rgomni = split(/\t/, $rg);
	my $ret = pop @rgomni;
	return $ret;
}
sub getpaths {
	my ($rootpath,$scriptroot,$reportpath,$omnipath,$config_path,$customer,$longrunning_hours,$historydays,$omnirpt,$omnidb,$omnicc,$omnidownload,$omnidbutil,$omnisv,$grp,@sysfolder);
	my (@ARGUMENTS) = @_;
	for ($i=0;$i<=$#ARGUMENTS;$i++) 
	{
		if ($ARGUMENTS[$i] =~ m/-debug/i)
        {
                $DEBUG = 1;
                print "DEBUG=> Debug Option Set \n" if ($DEBUG);
        }
		if ($ARGV[$i] =~ m/-scriptroot/i)
		{
				$i++;
				$scriptroot = $ARGV[$i];
		chomp $scriptroot;
		print "DEBUG=> Script Root  path: $scriptroot \n";
		}
        if ($ARGUMENTS[$i] =~ m/-rptpath/i)
        {
                $i++;
                $reportpath = $ARGUMENTS[$i];
				$reportpath = $reportpath."/" if $reportpath !~ m/\\$/;
                print "DEBUG=> configfile path: $reportpath \n" if ($DEBUG);
        }		
		if ($ARGUMENTS[$i] =~ m/-schdir_path/i)
        {
                $i++;
                $config_path = $ARGUMENTS[$i];
                print "DEBUG=> configfile path: $config_path \n" if ($DEBUG);
        }
	}	
	$rootpath = $scriptroot."/" if $scriptroot !~ m/\\$/;
	$parmfile = $rootpath."parameters.txt";
	if (-e $parmfile) 
	{
		open (PARMS,"< $parmfile") or &exit_msg("PATH","WARNING","unable to open $parmfile $!");
		while (<PARMS>) 
		{
				@line = split /=/;
				chomp $line[0]; chomp $line[1];
				$omnipath = $line[1] if ($line[0] eq "OMNIPATH" );chomp $omnipath;
				$reportpath = $line[1] if ($line[0] eq "RPTPATH" ); chomp $rootpath;
				$config_path = $line[1] if ($line[0] eq "OMNICONFIG" ); chomp $config_path;
				$customer = $line[1] if ($line[0] eq "CUSTOMER" ); chomp $config_path;
				$longrunning_hours = $line[1] if ($line[0] eq "LONGRUNNINGHOURS" );
				$historydays = $line[1] if ($line[0] eq "NOOFHISTORYDAYS" );
		}
	}
	unless ((defined $reportpath) and (-d $reportpath))
	{
		$reportpath = $rootpath."reports/";
	}	
	if ((!($longrunning_hours)) || (!($longrunning_hours =~ /^\d+$/)))
	{
		print "Longrunning hours not set .. taking default 6 Hours\n" if ($DEBUG);
		$longrunning_hours = 6;
	}
	if ((!($historydays)) || (!($historydays =~ /^\d+$/)))
	{
		print "No of History Days not set .. taking default 7 Hours\n" if ($DEBUG);
		$historydays = 7;
	}
	if (!($customer))
	{
		print "Customer name not set .. taking default CUSTOMER as Customer Name\n" if ($DEBUG);
		$customer = "CUSTOMER";
	}
	
	###############################################################################
	#Finding Paths
	#Registry reading for Windows
	#Default path for Unix.
	###############################################################################
	if ($os eq "WINDOWS") 
	{
		# Get Omniback dirctory from Registry
		unless (defined($omnipath))
		{
			print "DEBUG=> Accessing registry key ..HKEY_LOCAL_MACHINE\\SOFTWARE\\Hewlett-Packard\\OpenView\\OmniBackII\\Common..." if ($DEBUG);
			$regcont = "HKEY_LOCAL_MACHINE\\SOFTWARE\\Hewlett-Packard\\OpenView\\OmniBackII\\Common";
			$regkey = "HomeDir";
			$omnipath = getRegistryValue($regcont, $regkey);
		}
		print "DEBUG=> The omniback path is: $omnipath \n\n" if ($DEBUG);
		unless ((defined($omnipath)) and (-d $omnipath))
		{
			print "PATH ERROR \$omnipath not defined \n" if ($DEBUG);
			exit 1;
		}
		unless ((defined($config_path)) && (-d $config_path))
		{
			$config_path = "$omnipath"."config\\server\\schedules";
		}

		print "configpath -- $config_path \n" if ($DEBUG);

		#Assigning commands with paths to be used in this program
		$omnirpt = "\"$omnipath"."bin\\omnirpt.exe\"";
		$omnidb = "\"$omnipath"."bin\\omnidb.exe\"";
		$omnicc = "\"$omnipath"."bin\\omnicc.exe\"";
		$omnimm = "\"$omnipath"."bin\\omnimm.exe\"";
		$omnidownload = "\"$omnipath"."bin\\omnidownload.exe\"";
		$omnidbutil = "\"$omnipath"."bin\\omnidbutil.exe\"";
		$omnisv = "\"$omnipath"."bin\\omnisv.exe\"";
		$omnisvlogpath = "$omnipath"."log\\server\\omnisv.log";
		$grp = "find";
		@sysfolder = ("C:\\");
	}
	else 
	{
		unless (defined ($omnipath))
		{
			$omnipath = "/opt/omni/";
		}
		unless ((defined($config_path)) && (-d $config_path))
		{
			$config_path = (-d '/etc/opt/omni/server' )
			? "/etc/opt/omni/server/schedules"
			: "/etc/opt/omni";

		}
		print "The omniback path is: $omnipath \n\n" if ($DEBUG);
		unless (defined $omnipath and (-d $omnipath))
		{
			print "PATH ERROR \$omnipath not defined \n";
		}

			$omnirpt = $omnipath."bin/omnirpt";
			$omnidb = $omnipath."bin/omnidb";
			$omnicc = $omnipath."bin/omnicc";
			$omnimm = $omnipath."bin/omnimm";
			$omnidownload = $omnipath."bin/omnidownload";
			$omnidbutil = $omnipath."sbin/omnidbutil";
			$omnisv = $omnipath."sbin/omnisv";
			$omnisvlogpath = "/var/opt/omni/server/log/omnisv.log";
			$grp = "grep";
			@sysfolder = ("/");
	}
return ($rootpath,$reportpath,$omnipath,$config_path,$customer,$longrunning_hours,$historydays,$omnirpt,$omnidb,$omnicc,$omnidownload,$omnidbutil,$omnisv,$grp,$omnisvlogpath,@sysfolder)
}
sub freedspace 
{
	my($deviced) = @_;
	my ($freebytes,@splitdata);
	###################### Finding OS Type & Host Name #############################
	$ost = $^O;
	chomp $ost;
################################################################################
	chomp $deviced;
	if ($ost =~ m/win/i ) 
	{
		foreach $d (`dir \"$device\" /-c | find \"bytes free\"`)
		{
		  $d =~ m/\d+\s+Dir\(s\)\s+(\S+)\s*.*/;
		  $freebytes = $1;
		  $freembytes = int($freebytes/(1024 * 1024));
		}
	}
	elsif ($ost =~ m/hpux/i )
	{
		foreach $d (`bdf $deviced`)
		{
		chomp $d;
		  next if ($d =~ /filesystem/i);
		  $d =~ s/\//~/g; 
		  @splitdata = split /\s+/,$d;
		  $freembytes = $splitdata[3];
		  $freembytes = int($freembytes/(1024))
		}
	
	}
	else {
		foreach $d (`df -k $deviced`)
		{
		  next if ($d =~ /filesystem/i);
		  @splitdata = split /\s+/,$d;
		  $d =~ s/\//~/g;
		  $freembytes = $splitdata[3];
		  $freembytes = int($freembytes/(1024))
		}
		
	}
return ($freembytes);
}
sub dirSize { 
  my($dir)  = @_; 
  my($size) = 0; 
  my($fd); 
  
  opendir($fd, $dir) or die "$!";  
  for my $item ( readdir($fd) ) { 
    next if ( $item =~ /^\.\.?$/ );   
    my($path) = "$dir/$item";  
    $size += ((-d $path) ? dirSize($path) : (-f $path ? (stat($path))[7] : 0)); 
  }  
  closedir($fd);
  if ($size > 0)
  {
	$size = sprintf "%.2f",($size/(1024 * 1024));
   }
  return($size); 
}

sub libpool {
	my($libname) = @_;
	print "DEBUG=> $omnirpt -report media_list -library $libname -tab" if ($DEBUG);
	if (open LIBPOOL, "$omnirpt -report media_list -library \"$libname\" -tab 2>&1 |")
	{
		foreach (<LIBPOOL>)
		{
			chomp;
			next if /^#/;
			my($mstat,$poolname)= (split /\t/)[3,9];
			$libpm{$libname}{$poolname}{total}++;
			$md{$libname}{total}++;
			if ($mstat !~ /Good/i) {
			$md{$libname}{poor}++;
			}
		}
		close LIBPOOL;
	}
	else {
	print "DEBUG=> Error Running $omnirpt -report media_list -library $libname -tab" if ($DEBUG);
	}
	print "DEBUG=> $omnirpt -report media_list -library $libname -no_protection -tab" if ($DEBUG);
	if (open LIBPOOLSCR, "$omnirpt -report media_list -library \"$libname\" -no_protection -tab 2>&1 |")
	{
		foreach (<LIBPOOLSCR>)
		{
			chomp;
			next if /^#/;
			my($protection,$poolname)= (split /\t/)[4,9];
			$libpm{$libname}{$poolname}{scratch}++;
			$md{$libname}{scratch}++;
		}
		close LIBPOOLSCR;
	}
	else {
	print "DEBUG=> Error Running $omnirpt -report media_list -library $libname -tab" if ($DEBUG);
	}
}

sub libhiswebcreate {
	my ($fhandle,$libn,$rpt1type) = @_;
	$twidth = &tablesize($rpt1type);
	print $fhandle "<tr><td colspan = \"4\">\n";
	#print $fhandle "<p class = gridHeader>Pool Distribution: $libname</p>\n";
    print $fhandle "<table id=\"$libn\" width=\"$twidth\" border=\"2\" class=\"hide\">\n";
	print $fhandle "<tr><td colspan =\"4\"; class = \"hisHeader\">Pool Distribution: $libn</td>\n";
	my $count5 = 3; my $counter5 =1;
	@printdata = ("Pool Name", "Total No. of Media","No. of Scratch Media");
	&web2($fhandle,$count5,$counter5,$rpt1type,@printdata);
	my $count5 = 4;
	foreach $pooln (sort(keys(%{$libpm{$libn}})))
	{
		$libpm{$libn}{$pooln}{scratch} = &padingv($libpm{$libn}{$pooln}{scratch});
		@printdata = ("$pooln", "$libpm{$libn}{$pooln}{total}", "$libpm{$libn}{$pooln}{scratch}");
		&web2($fhandle,$count5,$counter5,$rpt1type,@printdata);
	}
	print $fhandle "<tr><td colspan =\"4\" class = \"gridHeader\" bgcolor=\"#FFFFFF\">&nbsp\;</td>";
	print $fhandle "</table>\n";
	print $fhandle "</td></tr>\n";
}
sub mediainfo {
#################################################
# Find MEDIARPT info using omnirpt command
################################################
	%libpm=();
	%md=();
	print "Running Media Info Data collection\n" if ($DEBUG);
	push (@reportlist,"I Media Status");
	push (@reportlist,"J Media Pool Status");
	$mediastat = $reportspecs{"I Media Status"}{"filepath"};
	$mediapoolstat= $reportspecs{"J Media Pool Status"}{"filepath"};
	open (MIDIASTAT, "> $mediastat") || die "unable to open \$mediastat - $mediastat \n";    
	open (POOLSTAT, "> $mediapoolstat") || die "unable to open \$mediapoolstat - $mediapoolstat \n";
	foreach $lib (sort(keys(%libinfo)))
	{
		&libpool($lib);
	}
	foreach $m_lib (sort(keys(%md)))
	{
		if ($m_lib)
		{
		#	map $_ = &checkval($_),($m_lib,$md{$m_lib}{total},$md{$m_lib}{scratch},$md{$m_lib}{poor});
			#$md{$m_lib}{poor} = 0 if (!(exists($md{$m_lib}{poor})));
			#$md{$m_lib}{scratch} = 0 if (!(exists($md{$m_lib}{scratch})));
			#$noscratch++ if ($md{$m_lib}{scratch} <= 0);
			$md{$m_lib}{poor} = &padingv($md{$m_lib}{poor});
			$md{$m_lib}{scratch} = &padingv($md{$m_lib}{scratch});
			
			print MIDIASTAT "$m_lib,$md{$m_lib}{total},$md{$m_lib}{scratch},$md{$m_lib}{poor}\n";
		}
	}
	print "DEBUG=> $omnirpt -report pool_list -tab" if ($DEBUG);
	if (open POOLINF, "$omnirpt -report pool_list -tab 2>&1 |")
	{
		while (<POOLINF>)
		{
			chomp;
			next if /^#/;
			($poolname,$fullmedia,$appnmedia,$freemdia,$totalmedia)= (split /\t/)[0,3,4,5,9];
			#print "$poolname,$fullmedia,$appnmedia,$freemdia,$totalmedia\n";
			$pool_freemdia++ if ($freemdia <= 0);
			$poolstat{$poolname}{fullmedia} = $fullmedia;
			$poolstat{$poolname}{appnmedia} = $appnmedia;
			$poolstat{$poolname}{freemdia} = $freemdia;
			$poolstat{$poolname}{totalmedia} = $totalmedia;
		}
		close POOLINF;
	}
	foreach $pooln (sort(keys(%poolstat)))
	{
		if (open PLS, "$omnimm -show_pool \"$pooln\" |")
		{
			foreach (<PLS>)
			{
				chomp;
				if (/^policy/i)
				{
					(undef,$inf) = split /\s*:\s*/;
					if ($inf =~ /Free pool/i)
					{
						$freepool{$pooln}{name} = $pooln;
					}
					else {
						$nonfreepool{$pooln}{name} = $pooln;
					}
				}
				if (/^Free pool support/i)
				{
					(undef,$inf) = split /\s*:\s*/;
					if ($inf !~ /^None/i)
					{
						$inf =~ m/\((.*)\)/;
						$nonfreepool{$pooln}{freepool} = $1;
					}
				}
			}
		}
		close PLS;
	}
	foreach $reppool (sort(keys(%nonfreepool)))
	{
		my $fpmedia = "";$totalfmedia = 0;
		if (exists($nonfreepool{$reppool}{freepool})) {
		$freep = $nonfreepool{$reppool}{freepool};
		}
		else
		{
			$freep = "None";
		}
		$fpmedia = $poolstat{$freep}{freemdia} if ($freep ne "None");
			$totalfmedia = $poolstat{$reppool}{freemdia} + $fpmedia;
		print POOLSTAT "$reppool,$poolstat{$reppool}{totalmedia},$poolstat{$reppool}{freemdia},$poolstat{$reppool}{fullmedia},$poolstat{$reppool}{appnmedia},$freep,$fpmedia,$totalfmedia\n";
	}
	close MIDIASTAT;
	close POOLSTAT;
}
sub padingv {
        ($b_pad) = @_;
        if ($b_pad == 0) {
                $b_pad = "0";
        }
return $b_pad;
}
1;
