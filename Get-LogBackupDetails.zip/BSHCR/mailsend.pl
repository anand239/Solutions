###############################################################
#
# FILE   : mailsend.pl
# DATE   : 01/09/2009
# VER    : 1.0
# AUTHOR : Yayathi Raju P
#          yayathi.raju@hp.com
# DESCRIPTION:
# Mail send script for Unix
#
###############################################################
##----------Reading Parameter File Path  --------------##
$scriptroot = $ARGV[0];chomp $scriptroot;
$rootpath = $scriptroot."/" if $rootpath !~ m/\\$/;
$parmfile = $rootpath."parameters.txt";
##----------Reading Parameter File----------------##
open (parm,"<$parmfile") or die "unable to open \$parmfile - $parmfile \n";
while (<parm>) {
        chomp $_;#print $_;
        next if /^$/;next if /^#/;
        @line = split /\s*=\s*/;
        $custm = $line[1] if ($line[0] eq "CUSTOMER" );
		$from = $line[1] if ($line[0] eq "FROM" );
        $to = $line[1] if ($line[0] eq "TO" );
}
close parm;
$rootpath =~ s/\\/\//g;
#print "$rootpath\n";

##----------Calculating Dates----------------------##
$time = time();
($sec,$min,$hour,$day,$month,$year,$wday,$yday,$isdst)=localtime($time);
$month = $month+1;
$year = 1900+$year;
if ($month <= 9) {
        $month = "0".$month;
}
if ($day <= 9) {
        $day = "0".$day;
}

$bshcrf = $rootpath."reports/BSHCR.htm";
$today = "$day/$month/$year";
$msgtemplate = $rootpath."reports/mailbody.txt";
&createmsgfile($today,$msgtemplate);

sub createmsgfile {
($prevday,$msgtemplate) = @_;
$serv = `hostname`;
chomp $serv;
open (msg, "> $msgtemplate") || die "unable to open $msgtemplate \n";
print msg "This is Automatically generated Backup Report for \n\n";
print msg "Customer: ".$custm."\n";
print msg "Server: ".$serv."\n";
print msg "Date: ".$prevday."\n\n";
print msg "Regards \n";
print msg "SAP Backup Team\n";
close msg;
}

$filename = "BSHCR.htm";
#$sr = `(cat $msgtemplate; /usr/bin/uuencode $bshcrf $filename) | mail -s "DP Backup Server Health Check Report for $custm" $to`;
#$sr = `(cat $msgtemplate; /usr/bin/uuencode $bshcrf $filename) | mailx ~m -s "$custm DP Backup Server Health Check Report" $to`;
#$sr = `(echo "Object.csv")|mailx -s "Daily BSR Object level:Mondelez_EMEA:DP:kftdershbck02.krft.net" -a $filename -r EMEA dailybsr\@hpe\.com`;
$sr = `(cat $msgtemplate)|mailx -s "$custm DP Backup Server Health Check Report" -a $rootpath/"reports/BSHCR.htm" $filename -r  $bshcrf $to`;
