######################################################
#   BSHCR - Startup Script
######################################################
scriptroot=$1
PERLP=`more ${scriptroot}/parameters.txt|sed -n '/^PERLPATH/p'|cut -d "=" -f2`
${PERLP}perl ${scriptroot}/st.pl ${scriptroot}/parameters.txt -scriptroot $scriptroot -all
${perlpath}perl ${scriptroot}/mailsend.pl $scriptroot
