##############################################################################
#
# FILE   : st.pl
# Ver    : 1.1
# DATE   : 01/09/2009
# AUTHOR : Yayathi Raju P
#          yayathi.raju@hp.com
#
# DESCRIPTION:
# Startup Script.
#
##########################Change History########################################
# 01/09/2009 Yayathi Raju P.	v1.0 Initial Version
# 01/09/2009 Yayathi Raju P.	v1.1 Updated with new enhancements (Media Report,IDB Status)
################################################################################
BEGIN {
	for ($i=0;$i<=$#ARGV;$i++) 
	{
		if ($ARGV[$i] =~ m/-scriptroot/i)
		{
				$i++;
				$scriptroot = $ARGV[$i];
		chomp $scriptroot;
		print "DEBUG=> Script Root  path: $scriptroot \n";
		}
	}
	unless ((defined $scriptroot) and (-d $scriptroot))
	{
		print "Error=> \$scriptroot not defined \n";
		exit 1;
	}
	push(@INC,$scriptroot);
}
use BSHCR;
use CONFIGR;
################################################################################
#&dp_shcr_main(@ARGV) if (defined(@ARGV));
&dp_shcr_main(@ARGV);

sub dp_shcr_main 
{
	@ARGUMENTS=@_;
###################### Finding OS Type & Host Name #############################
	$OSTYPE = $^O;
	$os="WINDOWS" if ($OSTYPE =~ m/win/i);
################################################################################
	@weekdays = qw(Sun Mon Tue Wed Thu Fri Sat);
	$PageTitle = 'BSHCR';
	$version = '1.1';
	%datahash = ();
	%linkstatus=();
	if ($#ARGUMENTS < 0)
	{
		&help;
		exit;
	}
	$argmnts = "@ARGUMENTS";
	if ($argmnts !~ m/-backup|-lib|-media|-idb|-disabledspec|-specmon|-all/)
	{
		&help;
		exit;
	}
	($rootpath,$reportpath,$omnipath,$config_path,$customer,$longrunning_hours,
	$historydays,$omnirpt,$omnidb,$omnicc,$omnidownload,$omnidbutil,$omnisv,$grp,$omnisvlogpath,@rootdir) = &getpaths(@ARGUMENTS);
	#print "st -root @rootdir \n";
	&report_init($reportpath);
	$criticalspecs = $rootpath."criticalspecsinp.csv";
	$complspecs = $reportpath."completedspecs.csv";	
	$unknsspecs =  $reportpath."unknownspecs.csv";
	$pri_report = $reportpath."BSHCR.htm";
	$cellserver = &cellservername();
	$dpversion = &dpversion();
	&check_arguments(@ARGUMENTS);
	open (PRI_REP, "> $pri_report") || die "unable to open \$pri_report \n";
	$fh="PRI_REP";
	&printhtml($fh);
	&printreport($historydays,$fh,@reportlist);
	&printlinks($fh,@reportlist);
	&copytemp($fh);
}

sub check_arguments {
#################################################
# Check the Command line arguments
# Execute the routine based on arguments
################################################
@ARGUMENTS=@_;
	$dpservstat = &dpstat;	
    foreach $argument (@ARGUMENTS) {
        chomp $argument;
        if (($argument =~ m/-backup/i) || ($argument =~ m/-all/i)) 
		{
			print "OPTION SESLECTED $argument \n" if ($DEBUG);
			if ($dpservstat == "RUNNING") 
			{							
				&sessioninfo($longrunning_hours);
			}
		}
        if (($argument =~ m/-lib/i) || ($argument =~ m/-all/i)) 
		{
            print "OPTION SESLECTED $argument \n" if ($DEBUG);
			if ($dpservstat == "RUNNING") 
			{							
				&libdetails;
				&mediainfo;
			}                
        }
		if (($argument =~ m/-idb/i) || ($argument =~ m/-all/i)) 
		{
             print "OPTION SESLECTED $argument \n" if ($DEBUG);
			if ($dpservstat == "RUNNING") 
			{
                &idbcstatus;
			}
				
        }
		if (($argument =~ m/-disabledspec/i) || ($argument =~ m/-all/i)) 
		{
            print "OPTION SESLECTED $argument \n" if ($DEBUG);
			if ($dpservstat == "RUNNING") 
			{
                &disabledspec;
			}
        }
		if (($argument =~ m/-specmon/i) || ($argument =~ m/-all/i)) 
		{
			if ($dpservstat == "RUNNING") 
			{
				print "OPTION SESLECTED $argument \n" if ($DEBUG);
                &criticalspecs;
			}				
        }
        if ($argument =~ m/-help/i) {
                print "OPTION SESLECTED $argument \n" if ($DEBUG);
                &help;
        }
    }
}

sub help {
  print "BSRRT - Data Collection Ver: $BSRRT_Version\n\n";
  print "Usage:";
  print "perl datacol.pl -scriptroot <scriptpath> -rptpath <CSVreportpath> -config_path <CSVreportpath> -options \n\n";
  print "Options:\n";
  print "  Data Collection of Backup Activity:\n";
  print "     -backup\n\n";
  print "  Data Collection Library Information:\n";
  print "     -lib\n\n";
  print "  Data Collection of Media Information:\n";
  print "     -media\n\n";
  print "  Data Collection of IDB Information:\n";
  print "     -idb\n\n";
  print "  Data Collection of disabledspec Information:\n";
  print "     -disabledspec\n\n";
  print "  Data Collection of Above All:\n";
  print "     -all\n\n";
  print "  For Help:\n";
  print "     -help\n\n";
}
