﻿Function Get-ListOfSessions
{
    [CmdletBinding()]
    Param(
    $InputObject
    )
    $ListOfSessions_converted = $InputObject.replace("`t",",")| Convertfrom-Csv -Header 'Session Type','Specification','Status','Mode','Start Time','Start Time_t','End Time','End Time_t','Queuing', 'Duration','GB Written','Media','Errors','Warnings','Pending DA','Running DA','Failed DA','Completed DA','Object','Files','Success','Session Owner','Session ID'
    $ListOfSessions_Result = $ListOfSessions_converted
    $ListOfSessions_Result
}

$CommandOutput = get-content "Input.txt"

$ListOfSessions = @(Get-ListOfSessions -InputObject $CommandOutput)

$AllSIDs = $ListOfSessions | where{$_.Specification -like "*KPW*"} | foreach{$i=0}{$_ | Add-Member Index ($i++) -PassThru}

$DailySIDs = $AllSIDs | where{$_.Specification -notlike "*Archive*"} 

foreach($DailySID in $DailySIDs)
{
    
    if($DailySID.status -eq "Failed")
    {
        break
    }
    $CompletedDailySID = $DailySID
}



$SIDs_After = $AllSIDs | where{$_.index -ge $CompletedDailySID.Index}

$ArchiveSIDs = $SIDs_After | where{$_.Specification -like "*Archive*"} 

foreach($ArchiveSID in $ArchiveSIDs)
{
    
    if($ArchiveSID.status -eq "Failed")
    {
        break
    }
    $CompletedArchiveSID = $ArchiveSID
}


